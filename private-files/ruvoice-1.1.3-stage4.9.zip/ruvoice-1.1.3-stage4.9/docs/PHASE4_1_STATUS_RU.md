# RuVoice — этап 4.1: проверка первой модели RUAccent

## Цель этапа

Изолированно проверить первый компонент пайплайна RUAccent — BERT-классификатор `nn_stress_usage`. На этом этапе остальные три ONNX-модели не скачиваются и не подключаются к приложению.

Набор файлов закреплён за репозиторием `TigreGotico/stressonnx-models` и commit `cb1594ddf81928e678a3a7ee7a22415e6e3a218f`:

- `nn_stress_usage/model.int8.onnx`
- `nn_stress_usage/tokenizer.json`
- `nn_stress_usage/config.json`

## Добавлено

- `tools/probe_ruaccent_stage41.py` — отдельная CLI-команда для скачивания только этих трёх файлов и последующей проверки локальной копии.
- Проверка commit-pinned URL, размера ONNX-файла, грубого protobuf-заголовка, JSON-структуры токенизатора, словаря токенов и меток `STRESS` / `NO_STRESS`.
- Расчёт SHA-256 локальных файлов и запись `stage4.1-verification.json`.
- Опциональная глубокая проверка `onnx.checker`, если в среде установлен пакет `onnx`.
- Unit-тесты на manifest pinning, успешную проверку синтетического набора, слишком маленький/неправильный ONNX-файл и неверную карту меток.

## Запуск

Из корня проекта на компьютере с доступом к Hugging Face:

```bash
python tools/probe_ruaccent_stage41.py download ./build/ruaccent-stage41
```

Повторная проверка уже скачанных файлов:

```bash
python tools/probe_ruaccent_stage41.py verify ./build/ruaccent-stage41
```

Глубокая проверка графа, если установлен пакет `onnx`:

```bash
python -m pip install onnx
python tools/probe_ruaccent_stage41.py verify ./build/ruaccent-stage41 --onnx-check
```

Локальные unit-тесты:

```bash
python -m pytest tools/tests/test_probe_ruaccent_stage41.py -q
```

## Результат текущей сессии

- Unit-тесты `tools/tests/test_probe_ruaccent_stage41.py`: **4/4 пройдены**.
- Portable-тесты механизма слияния RuVoice (`tools/run_stress_merger_tests.sh`): **18/18 пройдены**.
- Фактические веса здесь не скачаны: из контейнера нет DNS-доступа к `huggingface.co`. Поэтому этот этап не объявляется успешно проверенным на реальном ONNX-графе.
- Синтетический тестовый файл подтверждает только поведение проверяющего кода; он не является моделью и не должен подаваться ONNX Runtime.
- APK, Android-интеграция и инференс на Redmi на этапе 4.1 не меняются.

## Следующий маленький этап

Скачать реальные три файла в доступной сети, выполнить `verify --onnx-check`, сохранить получившиеся SHA-256 и подтвердить, что выходная карта классов и tokenizer соответствуют Kotlin-коду. Только после этого переходить к первому реальному ONNX-инференсу.
