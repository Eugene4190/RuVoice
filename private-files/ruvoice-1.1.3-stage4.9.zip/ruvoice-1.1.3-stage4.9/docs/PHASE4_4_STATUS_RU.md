# RuVoice — этап 4.4: отдельная проверка `nn_yo_homograph`

## Цель

Подготовить небольшой, воспроизводимый этап для отдельной проверки классификатора RUAccent, который выбирает, нужно ли токену соответствовать `ё`. На этом этапе не меняется Android-конвейер и не скачиваются остальные три модели.

## Что добавлено

- `tools/probe_ruaccent_yo.py` — отдельные команды `download`, `verify`, `evaluate` для трёх артефактов `nn_yo_homograph`: ONNX, tokenizer и config.
- Закреплена ревизия модели `cb1594ddf81928e678a3a7ee7a22415e6e3a218f`, без плавающей ссылки `main`.
- Проверяются ONNX-заголовок/минимальный размер, структура WordPiece tokenizer, карта меток с классом `YO`, SHA-256 и при наличии `onnx` — полный `onnx.checker`.
- Диагностический корпус `tools/data/ruaccent_yo_smoke.json`: восемь контекстов, включая документированную пару «Все люди пришли» (`NO_YO`) и «Он все знает» (`YO`), а также `чем/чём` и несколько обычных е/ё слов.
- Отдельная оценка `YO`/`NO_YO` с вероятностями и выравниванием WordPiece к словам.

## Команды

```bash
python -m pip install -r tools/requirements-stage42.txt
python tools/probe_ruaccent_yo.py download ./build/ruaccent-stage44
python tools/probe_ruaccent_yo.py verify ./build/ruaccent-stage44 --onnx-check
python tools/probe_ruaccent_yo.py evaluate ./build/ruaccent-stage44
```

`evaluate` запускает настоящий CPU ONNX-инференс. `verify` проверяет только локальные артефакты.

## Границы этапа

- Классификатор предсказывает метку `YO`/не-`YO`; этот probe не применяет словари `yo_words` и `yo_homographs` и не переписывает текст.
- Результат небольшого корпуса — диагностический сигнал, не оценка общей точности восстановления «ё».
- Модельный файл, tokenizer и config должны быть загружены на машине, где выполняется команда. В среде разработки текущего этапа DNS к `huggingface.co` недоступен, поэтому реальный ONNX-инференс и содержимое весов проверить не удалось.
- Android-код, APK и синтезатор Ilya не менялись.

## Проверки в среде разработки

- `python -m pytest tools/tests -q`: 29/29 тестов пройдены (8 новых тестов этапа 4.4 + предыдущие тесты этапов 4.1–4.3).
- `bash tools/run_stress_merger_tests.sh`: 18/18 portable Kotlin-тестов слияния прошли.
- `python -m py_compile tools/probe_ruaccent_yo.py tools/tests/test_probe_ruaccent_yo.py`: прошёл.
- Синтетический тестовый ONNX session подтверждает путь выравнивания токенов и агрегацию `YO`-оценки по слову. Это тест кода probe, не настоящий инференс весов.
- Проверка реального файла модели не выполнена: среда разработки не имеет DNS-доступа к `huggingface.co`; `onnxruntime`, `tokenizers` и `onnx` в ней не установлены.
- Android-приложение и APK не менялись.
