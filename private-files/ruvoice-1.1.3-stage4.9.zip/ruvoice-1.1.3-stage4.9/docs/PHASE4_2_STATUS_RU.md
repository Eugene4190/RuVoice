# RuVoice — этап 4.2: smoke-test настоящего `nn_stress_usage` ONNX

## Цель этапа

Подготовить изолированный проверочный запуск первой ONNX-модели RUAccent — BERT-классификатора `STRESS` / `NO_STRESS` — без подключения к Android-приложению и без загрузки остальных трёх моделей.

Важно: `nn_stress_usage` **не выбирает ударную гласную и не разрешает омографы**. Она предсказывает для каждого слова, нужно ли проходить дальнейшую процедуру постановки ударения. Положение ударения выбирается последующими компонентами конвейера RUAccent.

## Что добавлено

- `tools/probe_ruaccent_stress_usage.py` — CLI для одного реального инференса на коротком русском предложении.
- Проверка реальной ONNX-сигнатуры через ONNX Runtime:
  - `input_ids` и `attention_mask` обязательны;
  - `token_type_ids` передаётся, если его требует граф;
  - все входы должны иметь тип `tensor(int64)`;
  - первый выход должен быть token-classification logits формы `[batch, sequence, labels]`.
- WordPiece token-to-word alignment по `tokenizer.json`, с тем же способом группировки continuation-токенов `##`, что и в референсной реализации stressonnx.
- Усреднение вероятностей частей слова и выбор `STRESS` / `NO_STRESS` по слову.
- Запрет на неявное усечение входа: проверочный текст длиннее 512 токенов отклоняется с понятной ошибкой.
- JSON-режим для сохранения результатов теста.
- `tools/requirements-stage42.txt` с зависимостями только для запуска preflight-теста на компьютере.

## Как запустить после получения реальных файлов

Из корня проекта:

```bash
python -m pip install -r tools/requirements-stage42.txt
python tools/probe_ruaccent_stage41.py download ./build/ruaccent-stage41
python tools/probe_ruaccent_stress_usage.py ./build/ruaccent-stage41 \
  --text "В замке за дверью сломался замок."
```

JSON-вывод:

```bash
python tools/probe_ruaccent_stress_usage.py ./build/ruaccent-stage41 \
  --text "Все люди пришли, и всё уже готово." --json
```

Тесты без скачивания весов:

```bash
python -m pytest tools/tests/test_probe_ruaccent_stage41.py \
  tools/tests/test_probe_ruaccent_stress_usage.py -q
bash tools/run_stress_merger_tests.sh
```

## Проверки в текущей среде

- Тесты проверки артефактов этапа 4.1: **4/4**.
- Тесты интерфейса и постобработки `nn_stress_usage`: **8/8**.
- Предыдущие portable-тесты слияния исправлений: **18/18**.
- Скрипт проверен на синтетической сессии ONNX Runtime (fake session), включая формы входов/выходов, типы тензоров, wordpiece alignment, агрегацию субслов и отказ от усечения.
- Реальный ONNX-инференс пока **не запускался**: в текущем контейнере нет `onnxruntime` и `tokenizers`, нет DNS-доступа к `huggingface.co`, а реальные веса в архив не включены. Синтетическая сессия не является моделью и не доказывает качество нейросети.
- Android-код, APK, поток TTS и голос Ilya не менялись.

## Что считается завершением этапа 4.2

Этап закрывается только после запуска команды `probe_ruaccent_stress_usage.py` на настоящем `model.int8.onnx` с установленными `onnxruntime` и `tokenizers`, успешной проверки реальной сигнатуры графа и получения словесных меток на примере. Пока это не выполнено, результат считается подготовленным smoke-test harness, а не проверенной моделью.

## Следующий небольшой этап

После успешного реального инференса проверить одну отдельно выбранную модель следующего звена. Не подключать её в RuVoice до тех пор, пока standalone smoke-test не прошёл.
