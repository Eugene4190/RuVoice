package ru.kost.ruvoice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import ru.kost.ruvoice.text.Emoji
import ru.kost.ruvoice.text.Marks
import ru.kost.ruvoice.text.Normalizer
import ru.kost.ruvoice.text.Replacements
import ru.kost.ruvoice.text.Rules
import ru.kost.ruvoice.text.Segment

class PipelineTest {
    private val d = TestData.data()

    /** Неразрывный пробел не у цифры — обычный ещё до замен: regex-правило с пробелом в ключе его находит; у цифр — как был. */
    @Test fun nbspBetweenWordsBecomesSpace() {
        assertEquals("в кому, т. е. 1\u00a0200\u00a0000 и 5\u00a0км", Pipeline.wordSpaces("в\u00a0кому, т.\u202fе. 1\u00a0200\u00a0000 и 5\u00a0км"))
        val r = ru.kost.ruvoice.text.Replacements.parse(listOf("~впала в кому = впала в к+ому"))
        assertEquals("Эмма впала в к+ому.", Pipeline.plan("Эмма впала\u00a0в\u00a0кому.", d, 0, 0, r).single().text)
    }

    @Test fun plainTextToSentencesWithPauses() {
        val s = Pipeline.plan("Раз. Два!\nТри?", d, sentencePauseMs = 100, paragraphPauseMs = 300)
        assertEquals(listOf(
            Segment("Раз.", breakMs = 100), Segment("Два!", breakMs = 400, paragraph = true), Segment("Три?", breakMs = 100)
        ), s)
    }

    @Test fun ssmlKeepsProsodyPerSentence() {
        val s = Pipeline.plan("<speak><prosody rate=\"fast\">Раз. Два.</prosody><break time=\"1s\"/></speak>", d, 0, 300)
        assertEquals(listOf(Segment("{prosody:120:100}Раз."), Segment("{prosody:120:100}Два.", breakMs = 1000)), s)
    }

    @Test fun prosodyCarriedUntilReset() {
        val s = Pipeline.plan("<speak><prosody rate=\"fast\">Раз. Два.</prosody> Три. Четыре.</speak>", d, 0, 0)
        assertEquals(listOf(Segment("{prosody:120:100}Раз."), Segment("{prosody:120:100}Два."), Segment("{prosody}Три."), Segment("Четыре.")), s)
    }

    @Test fun prosodyBeforeSpeechDash() {
        val s = Pipeline.plan("<speak><prosody rate=\"fast\">— Привет, — сказал он.</prosody></speak>", d, 0, 0)
        assertEquals(listOf(Segment("{prosody:120:100}— Привет,", speech = true), Segment("{prosody:120:100}сказал он.")), s)
    }

    @Test fun pauseMarkerInPlainTextBecomesBreak() {
        // маркер прямо в исходном тексте, без словаря замен
        val s = Pipeline.plan("Раз.{pause:700}Два.", d, sentencePauseMs = 0, paragraphPauseMs = 300)
        assertEquals(listOf(Segment("Раз.", breakMs = 700), Segment("Два.")), s)
    }

    @Test fun pauseMarkerInsideSentenceStaysInText() {
        // внутри предложения маркер не режет — Marks сделает из него запятую заданной длины
        val s = Pipeline.plan("Он ушёл{pause:500}и всё. Два.", d, sentencePauseMs = 0, paragraphPauseMs = 0)
        assertEquals(listOf(Segment("Он ушёл{pause:500}и всё."), Segment("Два.")), s)
        val r = Pipeline.plan("Он ушёл {pause:500} и всё.", d, sentencePauseMs = 0, paragraphPauseMs = 0)
        assertEquals(listOf(Segment("Он ушёл {pause:500} и всё.")), r)
    }

    @Test fun pauseMarkerAtStartProducesEmptyLeadingSegment() {
        val s = Pipeline.plan("{pause:300}Раз.", d, sentencePauseMs = 0, paragraphPauseMs = 0)
        assertEquals(listOf(Segment("", breakMs = 300), Segment("Раз.")), s)
    }

    @Test fun twoConsecutivePauseMarkersSum() {
        val s = Pipeline.plan("Раз.{pause:200}{pause:300}Два.", d, sentencePauseMs = 0, paragraphPauseMs = 0)
        assertEquals(listOf(Segment("Раз.", breakMs = 500), Segment("Два.")), s)
    }

    @Test fun pauseMarkerThroughReplacement() {
        val r = Replacements.parse(listOf("*** = {pause:800}"))
        val s = Pipeline.plan("Раз. *** Два.", d, sentencePauseMs = 0, paragraphPauseMs = 0, replacements = r)
        assertEquals(listOf(Segment("Раз.", breakMs = 800), Segment("Два.")), s)
    }

    @Test fun pauseMarkerOverflowClampedTo10000() {
        val s = Pipeline.plan("Раз.{pause:99999}Два.", d, sentencePauseMs = 0, paragraphPauseMs = 0)
        assertEquals(listOf(Segment("Раз.", breakMs = 10000), Segment("Два.")), s)
    }

    @Test fun severalSentencesInPieceBeforeMarker() {
        val s = Pipeline.plan("Раз. Два.{pause:500}Три.", d, sentencePauseMs = 0, paragraphPauseMs = 0)
        assertEquals(listOf(Segment("Раз."), Segment("Два.", breakMs = 500), Segment("Три.")), s)
    }

    @Test fun pauseMarkerAtEndOfSegmentDoesNotDuplicateText() {
        // финальный fix-раунд п.4: пустой кусок после {pause:N} в конце сегмента раньше добавлял
        // весь исходный сегмент (с текстом и неразобранным маркером) ещё раз.
        val s = Pipeline.plan("<speak>Привет.{pause:300}<break time=\"200ms\"/>Пока.</speak>", d, 0, 0)
        assertEquals(1, s.count { it.text == "Привет." })
    }

    @Test fun pauseMarkerAtParagraphEndKeepsParagraphPause() {
        // финальный fix-раунд п.11: {pause:N} на конце абзаца — маркер про паузу предложения
        // (ruling), но пауза абзаца и флаг paragraph должны сохраниться, а не потеряться.
        val s = Pipeline.plan("Раз.{pause:300}\n\nДва.", d, sentencePauseMs = 100, paragraphPauseMs = 500)
        assertEquals(listOf(Segment("Раз.", breakMs = 800, paragraph = true), Segment("Два.", breakMs = 100)), s)
    }

    @Test fun directSpeechDashAndQuoteDetected() {
        // Splitter режет по «!»; «— сказал он.» — тире + строчная, это автор, не реплика.
        // ««Тише», — шепнул кто-то.» — реплика и авторская часть отдельными сегментами.
        val s = Pipeline.plan("Он вошёл. — Привет! — сказал он. «Тише», — шепнул кто-то.", d, 0, 0)
        assertEquals(listOf("Он вошёл.", "— Привет!", "— сказал он.", "«Тише»,", "шепнул кто-то."), s.map { it.text })
        assertEquals(listOf(false, true, false, true, false), s.map { it.speech })
    }

    @Test fun authorInsertInsideDirectSpeech() {
        // «— Пойдём, — сказал он, — нам пора.» → реплика / автор / реплика; пауза предложения и
        // флаг абзаца — только у последнего куска.
        val s = Pipeline.plan("— Пойдём, — сказал он, — нам пора.\n\nОн встал.", d, sentencePauseMs = 100, paragraphPauseMs = 500)
        assertEquals(listOf("— Пойдём,", "сказал он,", "нам пора.", "Он встал."), s.map { it.text })
        assertEquals(listOf(true, false, true, false), s.map { it.speech })
        assertEquals(listOf(0, 0, 600, 100), s.map { it.breakMs })
        assertEquals(listOf(false, false, true, false), s.map { it.paragraph })
    }

    @Test fun dashInsideDirectSpeechIsNotAuthorInsert() {
        // Перед авторской вставкой стоит знак («— Пойдём, — сказал»), перед тире внутри речи — нет.
        val s = Pipeline.plan("— Нам пора — уже поздно. — Да? — удивился он. — Ну — пошли.", d, 0, 0)
        assertEquals(listOf("— Нам пора — уже поздно.", "— Да?", "— удивился он.", "— Ну — пошли."), s.map { it.text })
        assertEquals(listOf(true, true, false, true), s.map { it.speech })
    }

    @Test fun replyContinuesAcrossSentencesInParagraph() {
        // Реплика из нескольких предложений в одном абзаце: второе без тире — продолжение речи,
        // авторский хвост рвёт цепочку, дальше снова автор. Новый абзац цепочку не наследует.
        val s = Pipeline.plan("— Привет. Как дела? — сказал он. Потом ушёл.\n\nНастала тишина.", d, 0, 0)
        assertEquals(listOf("— Привет.", "Как дела?", "— сказал он.", "Потом ушёл.", "Настала тишина."), s.map { it.text })
        assertEquals(listOf(true, true, false, false, false), s.map { it.speech })
        // Кавычки: закрывающая «»» кончает реплику.
        val q = Pipeline.plan("«Привет. Как дела?» — спросил он. Потом ушёл.", d, 0, 0)
        assertEquals(listOf(true, true, false, false), q.map { it.speech })
    }

    @Test fun replyWithoutDashDetectedByAuthorTail() {
        // Читалка отдаёт по предложению: «Как дела? — спросил он.» приходит без начала реплики.
        // Авторская вставка (знак + « — » + строчная) или авторский хвост следом — признак речи.
        assertEquals(listOf(true, false), Pipeline.plan("Как дела? — спросил он.", d, 0, 0).map { it.speech })
        assertEquals(listOf(true, false, true), Pipeline.plan("Как дела, — спросил он, — всё хорошо?", d, 0, 0).map { it.speech })
        assertEquals(listOf(false, false), Pipeline.plan("Он вышел. Дверь хлопнула.", d, 0, 0).map { it.speech })
    }

    @Test fun dashInsideWordIsNotSpeech() {
        val s = Pipeline.plan("Дефис-внутри слова.", d, 0, 0)
        assertEquals(listOf(false), s.map { it.speech })
    }

    @Test fun ssmlDirectSpeechDetectedBySameCriterion() {
        val s = Pipeline.plan("<speak>— Реплика.</speak>", d, 0, 0)
        assertEquals(listOf(true), s.map { it.speech })
    }

    // TalkBack при посимвольной навигации/эхе ввода шлёт запрос из одной буквы — читаем её по имени.
    @Test fun loneLetterRequestIsSpelled() {
        fun first(t: String, rules: Rules = Rules()) = Pipeline.plan(t, d, 0, 0, rules = rules).single().text
        assertEquals("б+ээ.", first("б"))   // в конце фразы зажим хвоста: гласную удваиваем
        assertEquals("б+ээ.", first(" Б. "))
        assertEquals("прописная буква в+э", first("прописная буква В."))
        assertEquals("м+ягкий знак", first("ь"))
        assertEquals("б+ии.", first("b"))
        assertEquals("у+ай.", first("Y"))
        assertEquals("з+эдд, заглавная", first("Заглавная Z"))
        assertEquals("в+э.", first("в"))
        assertEquals("ч+ээ.", first("Ч"))
        assertEquals("ч+э, заглавная", first("Ч Заглавная"))
        assertEquals("— +ы", first("Ы"))
        assertEquals("прописная буква +ы", first("прописная буква Ы."))   // со словами вокруг — обычное имя
        assertEquals("ц+э, заглавная", first("Ц Заглавная"))   // Jieshuo
        assertEquals("+и краткое, заглавная буква", first("Й, заглавная буква"))
        assertEquals("п+э, заглавная", first("Заглавная П"))   // имя буквы вперёд
        assertEquals("+ы, заглавная буква", first("заглавная буква Ы"))
        assertEquals("в заглавной роли", first("в заглавной роли"))
        assertEquals("+ээр.", first("р"))   // «+эр» модель читает «р»
        assertEquals("прописная буква +энн", first("прописная буква Н."))
        assertEquals("+эмм.", first("м"))
        assertEquals("+эмм.", first("m"))    // латинские M и N — как русские М и Н
        assertEquals("+энн.", first("N"))
        assertEquals("у+ай.", first("y"))    // /waɪ/: ударение на «ай», не «У́-ай»
        assertEquals("з+эдд.", first("Z"))    // «з+ед» модель читает «зет»
        assertEquals("удаление, у+ай, заглавная", Pipeline.plan("Удаление заглавная Y", d, 0, 0, rules = Rules().screenReader()).single().text)
        // внутри текста «в» — предлог, не трогаем
        assertEquals("в 1917 году.", first("в 1917 году."))
        assertEquals("б", first("б", Rules(off = setOf("letter_name"))))
    }
    // одиночный знак, которого нет в алфавите модели, — по имени, а не тишина
    @Test fun loneSymbolRequestIsNamed() {
        fun first(t: String, rules: Rules = Rules()) = Pipeline.plan(t, d, 0, 0, rules = rules).single().text
        assertEquals("решётка", first("#"))
        assertEquals("стрелка вправо", first(" → "))
        assertEquals("#", first("#", Rules(off = setOf("letter_name"))))
    }
    @Test fun fastStartCutsOnlyFirstSegment() {
        val long = "Поздним вечером старый смотритель запер тяжёлые ворота, пошёл вдоль стены, а потом долго стоял у окна и смотрел, как гаснут огни в деревне за рекой, где его никто не ждал."
        val text = "$long\n$long"
        val off = Pipeline.plan(text, d, 100, 300)
        assertEquals(2, off.size)
        val on = Pipeline.plan(text, d, 100, 300, rules = Rules(off = setOf("fast_start")))
        assertEquals(3, on.size)
        assertEquals(Segment("Поздним вечером старый смотритель запер тяжёлые ворота, пошёл вдоль стены"), on[0])
        assertEquals(Segment(long.substring(on[0].text.length + 2), breakMs = 400, paragraph = true), on[1])
        assertEquals(off[1], on[2])
    }

    @Test fun screenReaderFastStartByDefault() {
        // сообщение из чата без точек — у чтеца первый кусок режется по запятой, у книг по умолчанию нет
        val msg = "Иван Петров, ребята кто знает где можно купить нормальный зарядник для редми ноут тринадцать а то мой сдох вчера, 19:05"
        assertEquals(1, Pipeline.plan(msg, d, 0, 0).size)
        val sr = Pipeline.plan(msg, d, 0, 0, rules = Rules().screenReader())
        assertEquals(listOf(Segment("Иван Петров"), Segment(msg.substringAfter(", "))), sr)
    }

    @Test fun fastStartCountsModelLength() {
        val sr = Rules().screenReader()
        // ссылка: 89 символов исходного текста, для модели 215 — голова до ссылки
        val link = "Иван Петров, Смотрите https://t.me/c/1234567890/98765?thread=4321 тут всё написано, 19:05"
        val a = Pipeline.plan(link, d, 0, 0, rules = sr)
        assertEquals("Иван Петров", a.first().text)
        // хвост для модели длиннее предела чтеца (200) — режется ещё по запятой, но весь на месте
        assertEquals(listOf("Смотрите https://t.me/c/1234567890/98765?thread=4321 тут всё написано", "19:05"), a.drop(1).map { it.text })
        // число: голова без длинного кода
        val num = "Иван Петров, ваш код 4815162342 номер заказа 20260927000123, 19:05"
        assertEquals("Иван Петров", Pipeline.plan(num, d, 0, 0, rules = sr).first().text)
        // эмодзи
        val old = Emoji.shared
        Emoji.shared = File(TestData.root(), "app/src/main/assets/emoji_ru.tsv").bufferedReader().useLines { Emoji(it) }
        try {
            val emo = "Иван Петров, 😂😂😂 ну вы даёте 👍🔥❤️🎉🙏😎🤣😭💯 молодцы, 19:05"
            assertEquals("Иван Петров", Pipeline.plan(emo, d, 0, 0, rules = sr).first().text)
        } finally { Emoji.shared = old }
        // короткая фраза без раздувания и одна ссылка без пробелов — как были
        assertEquals(1, Pipeline.plan("Кнопка, Назад", d, 0, 0, rules = sr).size)
        assertEquals(1, Pipeline.plan("https://t.me/c/1234567890/98765", d, 0, 0, rules = sr).size)
    }

    @Test fun fastStartLeavesShortFirstSegment() {
        val on = Pipeline.plan("Раз. Два!", d, 100, 0, rules = Rules(off = setOf("fast_start")))
        assertEquals(listOf(Segment("Раз.", breakMs = 100), Segment("Два!", breakMs = 100)), on)
    }


    @Test fun englishPhraseBecomesOwnSegment() {
        val t = "Он сказал: «I don't know what you mean», и ушёл. Потом вернулся."
        val s = Pipeline.plan(t, d, 100, 0, englishWords = 1)
        // на стыках со знаком — пауза запятой (по умолчанию 100 мс)
        assertEquals(listOf(
            Segment("Он сказал: «", breakMs = 100), Segment("I don't know what you mean", breakMs = 100, en = true), Segment("», и ушёл.", breakMs = 100),
            Segment("Потом вернулся.", breakMs = 100)), s)
        // без движка для английского — как раньше
        assertEquals(2, Pipeline.plan(t, d, 100, 0).size)
    }

    @Test fun englishSentenceKeepsPauseAndParagraph() {
        val s = Pipeline.plan("Эпиграф.\nHello, world!\nДальше.", d, 0, 300, englishWords = 1)
        assertEquals(listOf(Segment("Эпиграф.", breakMs = 300, paragraph = true), Segment("Hello, world!", breakMs = 300, paragraph = true, en = true),
            Segment("Дальше.")), s)
    }

    @Test fun punctuationOnlyPieceDropped() {
        val s = Pipeline.plan("«Nice to meet you», — сказала она.", d, 0, 0, englishWords = 1)
        assertEquals(listOf("Nice to meet you" to true, "сказала она." to false), s.map { it.text to it.en })
    }

    @Test fun letterEchoWithActionWord() {
        fun first(t: String) = Pipeline.plan(t, d, 0, 0, rules = Rules().screenReader()).single().text
        assertEquals("удаление, +ээр, заглавная", first("Удаление заглавная Р"))
        assertEquals("удаление, +ээр, заглавная", first("Удаление Р заглавная"))
        assertEquals("удаление, +ээр.", first("Удаление р"))
        assertEquals("+ээр, удалено", first("р удалено"))                         // Jieshuo msg_deleted
        assertEquals("+ээр, заглавная буква, удалено", first("Р Заглавная буква Р удалено"))  // upper_case_format
        assertEquals("удаление, в+э.", first("Удаление в"))                       // буква, не предлог: других слов нет
        assertEquals("удаление, в+э, заглавная", first("Удаление заглавная В"))
        assertEquals("удаление, — +ы", first("Удаление ы"))
        assertEquals("удаление, ч+ээ.", first("Удаление ч"))
        assertEquals("удаление, +ар, заглавная", first("Удаление заглавная R"))
        // шаблоны TalkBack
        assertEquals("текст, +ээр, прописная буква, удален", first("Текст прописная буква Р. удален."))
        assertEquals("вставлен текст, +ээр.", first("Вставлен текст \"р\""))
        assertEquals("+ээр, буква, удалена", first("Буква \"р\" удалена."))
        // удалённый знак — по имени
        assertEquals("удаление, запятая", first("Удаление ,"))
        assertEquals("текст, запятая, удален", first("Текст \",\" удален."))
        assertEquals("удаление, решётка", first("Удаление #"))
        // точка в конце фразы — не удалённый знак
        assertEquals("Текст удален.", first("Текст удален."))
        // обычный текст не трогаем
        assertEquals("Удаление в два этапа.", first("Удаление в два этапа."))
        assertEquals("Удаление файла Р.", first("Удаление файла Р."))
        // выключено правило — как раньше
        assertEquals("Удаление заглавная Р", Pipeline.plan("Удаление заглавная Р", d, 0, 0, rules = Rules().screenReader().with("letter_name", false)).single().text)
        // книги и приложения — только по тумблеру
        assertEquals("Удаление заглавная Р", Pipeline.plan("Удаление заглавная Р", d, 0, 0).single().text)
        assertEquals("удаление, +ээр, заглавная", Pipeline.plan("Удаление заглавная Р", d, 0, 0, rules = Rules().with("letter_echo_all", true)).single().text)
    }

    @Test fun englishJoinPauses() {
        // без знака на стыке — короткая пауза, со знаком — переданная (пауза запятой)
        val s = Pipeline.plan("Открыл Microsoft Word на iPhone, потом закрыл.", d, 0, 0, englishWords = 1, englishJoinMs = 150)
        assertEquals(listOf("Открыл" to 60, "Microsoft Word" to 60, "на" to 60, "iPhone" to 150, "потом закрыл." to 0),
            s.map { it.text to it.breakMs })
        // пауза выброшенного обрывка из знаков уходит соседу
        val q = Pipeline.plan("«Nice to meet you», — сказала она.", d, 0, 0, englishWords = 1, englishJoinMs = 150)
        assertEquals(listOf(150, 0), q.map { it.breakMs })
    }

    @Test fun latinLetterEchoStaysRussianNamed() {
        // набор по буквам: одиночная латинская буква и эхо с ней — имя буквы русским голосом, не другому движку
        val sr = Rules().screenReader()
        assertEquals(listOf("+ар." to false), Pipeline.plan("r", d, 0, 0, rules = sr, englishWords = 1).map { it.text to it.en })
        assertEquals(listOf("удаление, +ар, заглавная" to false), Pipeline.plan("Удаление заглавная R", d, 0, 0, rules = sr, englishWords = 1).map { it.text to it.en })
    }

    /** sr_link_word: разрез (быстрый старт, предел куска чтеца) не должен приходиться внутрь адреса —
     * иначе в модель уйдёт «ссылка» с обрывком сайта, а хвост адреса прочитается по частям. */
    @Test fun linkWordNotCutInsideUrl() {
        val pad = "Привет смотри что я нашёл вчера вечером когда искал новые голоса для телефона и читалки"
        val cases = listOf(
            "$pad https://example.com/list?ids=1,2,3,4,5&sort=asc,desc там всё есть",
            "https://example.com/" + "a".repeat(260) + " вот",
            "$pad www.ya.ru/page,part,two и ещё https://github.com/x/y,z потом",
            "a,b,c https://t.me/c/123,456/789 и " + "очень длинное сообщение без точек ".repeat(10),
        )
        for (srMax in listOf(100, 200)) for (msg in cases) {
            val r = Rules(off = setOf("sr_link_word"), srMaxLen = srMax).screenReader()
            val segs = Pipeline.plan(msg, d, 0, 0, rules = r)
            val model = segs.map { Normalizer.prepare(Marks.parse(it.text, 0).text, d.allowed, r) }
            // куски вместе — слово в слово как всё сообщение без разрезов: адрес нигде не порван
            fun words(t: String) = t.split(Regex("[^\\p{L}\\d+]+")).filter { it.isNotEmpty() }
            assertEquals("[$srMax] $msg", words(Normalizer.prepare(msg, d.allowed, r)), words(model.joinToString(" ")))
            assertEquals(msg, Regex("https?://|www\\.").findAll(msg).count(), model.sumOf { Regex("ссылка").findAll(it).count() })
            assertTrue(model.joinToString(" "), model.none { it.contains("слэш") || it.contains("аааа") })
            assertTrue(segs.size > 1)
        }
    }

    /** Предел куска чтеца меряется текстом для модели: ссылка и числа раздуваются, кусок режется раньше. Книги — по исходнику. */
    @Test fun srMaxLenMeasuredAfterNormalization() {
        val msg = "Привет смотри что нашёл вчера вечером https://github.com/snakers4/silero-models/issues?page=2 😀😀 " +
            "там пишут что новая версия читает быстрее и лучше а ещё можно настроить профили для книг и для чтеца так что попробуй " +
            "обязательно и напиши мне своё мнение про вариант номер 12345 когда будет время"
        val r = Rules(off = setOf("sr_fast_start"), srMaxLen = 200).screenReader()
        fun model(t: String, rr: Rules) = Normalizer.prepare(Marks.parse(t, 0).text, d.allowed, rr)
        val sr = Pipeline.plan(msg, d, 0, 0, rules = r)
        assertTrue(sr.all { model(it.text, r).length <= 200 })
        // книги: по исходнику, как было (предел 200 для сравнения)
        val parts = Rules(setOf("link_domain"), maxLen = 200) // ссылка по частям — длинная
        val books = Pipeline.plan(msg, d, 0, 0, rules = parts)
        assertTrue(books.any { model(it.text, parts).length > 200 })
    }
}
