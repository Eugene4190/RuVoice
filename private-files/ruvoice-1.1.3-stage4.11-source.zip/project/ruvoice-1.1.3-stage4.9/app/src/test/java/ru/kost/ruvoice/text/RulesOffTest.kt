package ru.kost.ruvoice.text

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import ru.kost.ruvoice.DictLines
import ru.kost.ruvoice.Pipeline
import ru.kost.ruvoice.TestData

/** Переключатели правил (вкладка «Правила»): выключенное правило не трогает текст. */
class RulesOffTest {
    private val d = TestData.data()
    private fun off(vararg keys: String) = Rules(off = keys.toSet())

    private val firstVowel = object : StressModels {
        override fun accentor(words: List<String>) = Pair(
            Array(words.size) { FloatArray(10).also { it[0] = 1f } },
            Array(words.size) { FloatArray(7).also { it[0] = 1f } })
        override fun homo(ids: List<LongArray>, starts: LongArray, ends: LongArray) = FloatArray(ids.size) { 0.9f }
    }

    @Test fun allOnByDefault() {
        assertEquals("в двадцатом веке", Normalizer.numbers("в XX веке"))
        assertEquals("в двадцатом веке", Normalizer.numbers("в XX веке", Rules()))
    }

    @Test fun romanOff() {
        assertEquals("в XX веке", Normalizer.numbers("в XX веке", off("roman")))
    }

    @Test fun romanNameOffKeepsTriggerRoman() {
        assertEquals("Пётр I в двадцатом веке", Normalizer.numbers("Пётр I в XX веке", off("roman_name")))
    }

    @Test fun numbersOffLeavesDigits() {
        assertEquals("глава 3", Normalizer.numbers("глава 3", off("numbers")))
    }

    @Test fun unitsOff() {
        assertEquals("около три км", Normalizer.numbers("около 3 км", off("units", "cases")))
    }

    @Test fun abbrevOff() {
        assertEquals("см. рис. три", Normalizer.numbers("см. рис. 3", off("abbrev")))
    }

    @Test fun spellCyrOffLatStillOn() {
        assertEquals("ФСБ и ю эс б+и", Abbrev.apply("ФСБ и USB", off("spell_cyr")))
    }

    @Test fun spellLatOff() {
        assertEquals("эф эс б+э и USB", Abbrev.apply("ФСБ и USB", off("spell_lat")))
    }

    @Test fun latinOffStillLowercases() {
        assertEquals("iphone", Normalizer.latin("iPhone", off("latin")))
    }

    @Test fun homoglyphsOff() {
        // латинская «o» внутри кириллического слова остаётся (транслитерация тоже выключена,
        // иначе она сама прочитает «o» как «о»)
        assertEquals("прoблема", Normalizer.latin("прoблема", off("homoglyphs", "latin")))
        assertEquals("проблема", Normalizer.latin("прoблема", Rules()))
    }

    @Test fun punctuationOff() {
        assertEquals("Ну!!! Да...", Normalizer.punctuation("Ну!!! Да...", off("punct")))
    }

    @Test fun speechOffNoSpeechSegments() {
        val s = Pipeline.plan("— Привет, — сказал он.", d, 0, 0, rules = off("speech"))
        assertEquals(1, s.size)
        assertTrue(s.none { it.speech })
    }

    @Test fun speechOnSplitsSpeech() {
        val s = Pipeline.plan("— Привет, — сказал он.", d, 0, 0, rules = Rules())
        assertTrue(s.any { it.speech })
    }

    @Test fun ssmlOffReadsTagsAsText() {
        val s = Pipeline.plan("<speak>Раз.</speak>", d, 0, 0, rules = off("ssml"))
        assertEquals("<speak>Раз.</speak>", s.single().text)
    }

    @Test fun dehyphenOff() {
        // мягкий перенос ещё работает: \n → пробел, дефис остаётся
        assertEquals(listOf("со- бака"), Splitter.paragraphs("со-\nбака", off("dehyphen")))
        assertEquals(listOf("собака"), Splitter.paragraphs("со-\nбака"))
    }

    @Test fun softBreakOffMakesParagraph() {
        assertEquals(listOf("раз", "два"), Splitter.paragraphs("раз\nдва", off("soft_break")))
        assertEquals(listOf("раз два"), Splitter.paragraphs("раз\nдва"))
    }

    @Test fun maxLenLimitsChunk() {
        val long = (1..60).joinToString(" ") { "слово" }  // 359 символов
        assertEquals(1, Splitter.sentences(long).size)
        assertTrue(Splitter.sentences(long, Rules(maxLen = 100)).size >= 3)
    }

    @Test fun intonationOff() {
        assertEquals("general_q", SentenceType.classify("Ты идёшь?", d))
        assertEquals("st", SentenceType.classify("Ты идёшь?", d, off("intonation")))
    }

    @Test fun homoOffFallsToAccentor() {
        assertEquals("з+амок", Stress(d, firstVowel, rules = off("homo")).apply("замок"))
    }

    @Test fun accentorOffLeavesWord() {
        assertEquals("мама", Stress(d, firstVowel, rules = off("accentor")).apply("мама"))
        // словарь исключений и пользовательский словарь по-прежнему работают
        assertEquals("мам+а", Stress(d, firstVowel, mapOf("мама" to "мам+а"), off("accentor")).apply("мама"))
    }

    @Test fun keysCoverEveryRule() {
        // каждый ключ, который знает UI, должен быть в списке — иначе тумблер ничего не выключает
        for (k in listOf("numbers", "cases", "roman", "roman_name", "dates", "day_month", "years", "times", "phones",
            "units", "degrees", "currency", "fractions", "spoons", "gen_suffix", "sections", "thousands",
            "footnotes", "abbrev", "spell_cyr", "spell_lat", "latin", "homoglyphs", "dehyphen", "soft_break",
            "punct", "ssml", "homo", "accentor", "prefix_space", "intonation", "exclaim", "question", "pause_semicolon", "lead_in", "symbol_names", "emoji", "sr_fast_start", "sr_symbols", "sr_quote_off", "sr_lead_in_off", "sr_pauses_off", "sr_keep_loaded"))
            assertTrue(k, k in Rules.KEYS)
    }

    /** «моя» — омограф из homodict (мо+я/м+оя): полный путь замены → Stress со системными словарями: местоимение из
     * словаря ударений, деепричастие — фразой из словаря замен (preset защищает от userDictPass). */
    @Test fun systemDictMoya() {
        val root = TestData.root()
        val stress = java.io.File(root, "app/src/main/assets/dicts/stress/Системный.txt").readLines().mapNotNull { DictLines.parseStress(it) }.toMap()
        val repl = Replacements.parse(java.io.File(root, "app/src/main/assets/dicts/replace/Системный.txt").readLines())
        // омографы решает «первый вариант по алфавиту» — для «моя» это «м+оя», так что верное чтение даёт только фраза
        val firstHomo = object : StressModels {
            override fun accentor(words: List<String>) = firstVowel.accentor(words)
            override fun homo(ids: List<LongArray>, starts: LongArray, ends: LongArray) = FloatArray(ids.size) { 0.1f }
        }
        val st = Stress(d, firstHomo, stress, off("gram"))
        assertEquals("+это м+оя ж+изнь.", st.apply("это моя жизнь."))
        assertEquals("+это мо+я ж+изнь.", st.apply(repl.apply("это моя жизнь.")))
        assertEquals("+он ст+оял, м+оя п+осуду.", st.apply(repl.apply("он стоял, моя посуду.")))
        assertEquals("+он ст+оял, м+оя г+олову.", st.apply(repl.apply("он стоял, моя голову.")))
        assertTrue(st.apply(repl.apply("сказали, что эта каюта теперь моя, показали, как с помощью")).contains(" мо+я,"))
    }

    /** Имена из Википедии через «е» не перебивают нарицательные с «ё»: «К+отел» — город, «котел» в книге — «котёл»
     * (отчёт пользователя 02.10.2026, tools/wiki_names.py). */
    @Test fun systemDictKeepsYo() {
        val stress = java.io.File(TestData.root(), "app/src/main/assets/dicts/stress/Системный.txt").readLines().mapNotNull { DictLines.parseStress(it) }.toMap()
        val yo = java.io.File(TestData.root(), "app/src/main/assets/eyo_safe.txt").bufferedReader().useLines { YoDict(it) }
        val st = Stress(d, firstVowel, stress, off("gram"), yo = yo)
        assertEquals("св+ет, +испускаемый фонар+ём, +и кот+ёл.", st.apply("свет, испускаемый фонарем, и котел."))
    }

    /** Строки tools/stress_fixes.txt с ключом через «е» и значением с «ё» («холеной = хол+ёной») доходят до модели с «ё». */
    @Test fun systemDictFixesYo() {
        val stress = java.io.File(TestData.root(), "app/src/main/assets/dicts/stress/Системный.txt").readLines().mapNotNull { DictLines.parseStress(it) }.toMap()
        val st = Stress(d, firstVowel, stress, off("gram"))
        assertEquals("хол+ёной р+укой, трёхс+отого г+ода, благоприобрет+ённого н+авыка.",
            st.apply("холеной рукой, трехсотого года, благоприобретенного навыка."))
    }

    /** Дефис после безударной приставки модель слышит пробелом; текст для подсветки не меняется. */
    @Test fun prefixHyphenForModel() {
        val stress = Stress(d, firstVowel, rules = off("homo", "gram"))
        val accented = stress.apply("Из-под по-другому кто-то в+о-первых")
        assertEquals("Из-п+од по-др+угому кт+о-то в+о-п+ервых", accented)
        assertEquals("Из п+од по др+угому кт+о-то в+о-п+ервых", stress.forModel(accented))
        assertEquals(accented, Stress(d, firstVowel, rules = off("prefix_space")).forModel(accented))
    }

    /** Конец входа модели: кусок без знака — с точкой, кроме слова с ударением на последний слог; end_oxy снимает точку
     * после такого слова. */
    @Test fun modelEnd() {
        val st = Stress(d, firstVowel)
        assertEquals("страд+ала." to true, st.modelEnd("страд+ала"))
        assertEquals("+она страд+ала." to true, st.modelEnd("+она страд+ала "))
        assertEquals("страд+ала." to false, st.modelEnd("страд+ала."))
        assertEquals("ст+ол." to true, st.modelEnd("ст+ол"))
        assertEquals("+ухо востр+о" to false, st.modelEnd("+ухо востр+о"))
        assertEquals("+ухо востр+о." to false, Stress(d, firstVowel, rules = off("end_oxy")).modelEnd("+ухо востр+о."))
        assertEquals("т+ы ид+ёшь?" to false, st.modelEnd("т+ы ид+ёшь?"))
        assertEquals("страд+ала" to false, Stress(d, firstVowel, rules = off("end_dot")).modelEnd("страд+ала"))
        val oxy = st
        assertEquals("+ухо востр+о" to false, oxy.modelEnd("+ухо востр+о."))
        assertEquals("он+и пошл+и дом+ой" to false, oxy.modelEnd("он+и пошл+и дом+ой."))
        assertEquals("н+а ст+ол." to false, oxy.modelEnd("н+а ст+ол."))
        assertEquals("+она страд+ала." to false, oxy.modelEnd("+она страд+ала."))
        assertEquals("востр+о…" to false, oxy.modelEnd("востр+о…"))
        assertEquals("востр+о!" to false, oxy.modelEnd("востр+о!"))
        assertEquals("востр+о..." to false, oxy.modelEnd("востр+о..."))
    }

    /** aidar: перед ударной «я» в начале куска — тире, больше нигде. */
    @Test fun yaOnsetDash() {
        val stress = Stress(d, firstVowel, rules = off("homo", "gram"))
        assertEquals("– +я пошёл дом+ой.", stress.yaOnset("+я пошёл дом+ой."))
        assertEquals("– +Я.", stress.yaOnset("+Я."))
        for (s in listOf("пот+ом +я пошёл.", "– +я пошёл.", "+ясно.", "яз+ык.", "+юля пришл+а."))
            assertEquals(s, stress.yaOnset(s))
        assertEquals("+эй!", stress.yaOnset("– +эй!"))  // тире реплики снимается
    }

    /** kseniya/eugene: перед двумя согласными в начале куска (и предлогом перед согласной) — тире, тире реплики
     * перед остальным снимается. */
    @Test fun clusterOnsetDash() {
        val stress = Stress(d, firstVowel, rules = off("homo", "gram"))
        for (s in listOf("Стр+ах.", "спас+ибо.", "Чт+о +это?", "Вст+ал.", "С т+ех п+ор.", "с п+омощью.", "К т+ому ж+е."))
            assertEquals("– $s", stress.clusterOnset(s))
        for (s in listOf("С+ад.", "+Утро.", "Он ушёл. Стр+ах.", "– Стр+ах.", "Сь.", "С +утра.", "в +это вр+емя."))
            assertEquals(s, stress.clusterOnset(s))
        assertEquals("д+аа.", stress.clusterOnset("– д+аа."))
        assertEquals("+эй, т+ы!", stress.clusterOnset("– +эй, т+ы!"))
        assertEquals("– с т+ех п+ор.", stress.clusterOnset("– с т+ех п+ор."))
    }

    /** Реплика из одного короткого слова на гласную: гласная сдвоена, всё остальное как есть. */
    @Test fun shortWordStretched() {
        val stress = Stress(d, firstVowel, rules = off("homo", "gram"))
        assertEquals("– д+аа.", stress.stretchShort("– д+а."))
        assertEquals("Кт+оо?", stress.stretchShort("Кт+о?"))
        assertEquals("– вс+ёё…", stress.stretchShort("– вс+ё…"))
        assertEquals("п+ишут см+ии.", stress.stretchShort("п+ишут см+и."))
        assertEquals("к см+и п+адает.", stress.stretchShort("к см+и п+адает."))
        assertEquals("оо...", stress.stretchShort("о..."))
        assertEquals("– +ии…", stress.stretchShort("– +и…"))
        assertEquals("+аа?", stress.stretchShort("+а?"))
        for (s in listOf("д+а", "н+у д+а.", "м+оя.", "н+ет.", "+я.", "стр+о.", "– д+а, к+онечно.", "– д+а. +я пойд+у.", "+я...", "+е?", "о, д+а.", "и т+ак.", "+и.", "– +а."))
            assertEquals(s, stress.stretchShort(s))
        assertEquals("– д+а.", Stress(d, firstVowel, rules = off("short_word")).stretchShort("– д+а."))
    }
}
