package ru.kost.ruvoice

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.EditText
import android.widget.TextView
import android.content.Context
import java.util.Locale
import androidx.core.os.ConfigurationCompat
import androidx.fragment.app.Fragment
import androidx.core.widget.doAfterTextChanged
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputLayout
import ru.kost.ruvoice.text.English
import ru.kost.ruvoice.text.Layers
import ru.kost.ruvoice.text.Rules

/**
 * Страница настроек: в onViewCreated читает Prefs в поля, в onPause пишет поля в Prefs.
 * ViewPager2 переводит невидимые страницы в STARTED, так что onPause срабатывает и при
 * смене вкладки, и при уходе из приложения — отдельная кнопка «Сохранить» не нужна.
 */
abstract class PageFragment(layout: Int) : Fragment(layout) {
    protected val prefs by lazy { Prefs(requireContext()) }
    protected abstract fun load(v: View)
    protected abstract fun save(v: View)

    /** Профиль, для которого загружены поля: сменился (плитка в шторке) — поля чужие, не сохранять. */
    private var loadedGen = -1
    private fun sameProfile() = Profiles(requireContext()).gen == loadedGen

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) { view.markHeadings(); loadedGen = Profiles(requireContext()).gen; load(view) }
    override fun onPause() {
        // recreate() после импорта (Task 25) сначала распускает старые фрагменты — им нельзя
        // затирать только что импортированный файл своими устаревшими полями.
        if (activity?.intent?.getBooleanExtra(SettingsActivity.EXTRA_IMPORT_DONE, false) != true && sameProfile()) view?.let { save(it) }
        super.onPause()
    }

    /** Принудительно сохранить поля в Prefs, не дожидаясь onPause — нужно перед экспортом
     * настроек, чтобы в файл попали несохранённые правки текущей (видимой) вкладки. */
    fun saveNow() { if (sameProfile()) view?.let { save(it) } }

    protected fun EditText.str() = text.toString()
}

/** Язык интерфейса (выбранный в «Язык и тема» или системный): для чисел и названий языков на экране. */
internal val Context.uiLocale: Locale get() = ConfigurationCompat.getLocales(resources.configuration)[0] ?: Locale.getDefault()

// Slider падает при layout, если значение не на сетке шага 0.05 (импорт «0.73»,
// старые quote_rate из текстового поля) — округляем к шагу и зажимаем в диапазон.
private fun snap(raw: Float, from: Float, to: Float) = (Math.round((raw - from) / 0.05f) * 0.05f + from).coerceIn(from, to)

/** Слайдер темпа/высоты: подпись «×1.25» над ним, поплавок «1,25» (по-английски «1.25») при перетаскивании. TalkBack
 * слышит один элемент — слайдер с названием [label] и значением из поплавка: строка подписи над
 * ним скрыта, а «×» из значения голос не произносит (или называет «знак умножения»). */
internal fun View.rateSlider(sliderId: Int, valueId: Int, raw: Float, label: String, from: Float = 0.5f, to: Float = 2f): Slider {
    val valueView = findViewById<TextView>(valueId)
    fun format(v: Float) = "×%.2f".format(Locale.ROOT, v)
    val value = snap(raw, from, to)
    valueView.text = format(value)
    (valueView.parent as View).importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
    return findViewById<Slider>(sliderId).apply {
        contentDescription = label
        setLabelFormatter { "%.2f".format(context.uiLocale, it) }
        this.value = value
        addOnChangeListener { _, v, _ -> valueView.text = format(v) }
    }
}

/** Подпись под полем (TextInputLayout.helperText) у поля-выпадашки; null — убрать. */
private fun View.helper(text: CharSequence?) {
    var p = parent
    while (p != null && p !is TextInputLayout) p = p.parent
    (p as? TextInputLayout)?.helperText = text
}

private fun View.dropdown(id: Int, items: List<String>, value: String) =
    findViewById<MaterialAutoCompleteTextView>(id).apply {
        setSimpleItems(items.toTypedArray())
        setText(value, false)
        opensFromKeyboard()
    }

/** Голос, частота и проверка (прослушать/разбор). Прямая речь — в «Настройках» (RulesFragment, в самом низу). */
class VoiceFragment : PageFragment(R.layout.fragment_voice) {
    private val rates = listOf(48000, 24000)
    private val d by lazy { SileroModels.data(requireContext()) }
    private val packs by lazy { Packs.installed(requireContext().filesDir) }
    // Список голосов из модели и установленных паков (Speaker.names), в списке подписи Speaker.label.
    private val voices by lazy { Speaker.names(d, packs) }
    private fun nameOf(label: String) = voices.firstOrNull { Speaker.label(it) == label }
    private val rateItems by lazy { rates.map { getString(R.string.sample_rate_item, it) } }
    /** Голоса из prefs нет на телефоне (профиль или файл с другого телефона, пак удалили): в выпадашке —
     * тот, которым сейчас читается, но в prefs он не пишется, пока голос не выберут сами, — вернули пак,
     * и профиль снова читает своим голосом. */
    private var voiceKept = false

    override fun load(v: View) {
        // lite без пака: голосов нет — пустые выпадашки, кнопки ниже ничего не делают.
        // Через Speaker.resolve: в lite голое «aidar» из старых prefs — это «ru/aidar» из voices.
        val main = Speaker.resolve(prefs.voice, d, packs)?.name ?: Speaker.default(d, packs)?.name ?: ""
        val voiceView = v.dropdown(R.id.voice, voices.map { Speaker.label(it) }, Speaker.label(main))
        voiceKept = voices.isNotEmpty() && Speaker.resolve(prefs.voice, d, packs) == null
        voiceView.missing(if (voiceKept) prefs.voice else null, Speaker.label(main))
        if (!voiceKept) voiceView.bound(main)
        var shown = voiceView.str()
        voiceView.setOnItemClickListener { _, _, _, _ ->
            val picked = nameOf(voiceView.str())
            val bound = picked?.let { Profiles(requireContext()).boundOther(it) }
            if (bound != null) {
                // голос привязан к другому профилю — включается тот, с этим голосом; у этого голос прежний
                voiceView.setText(shown, false)
                val host = activity as SettingsActivity
                host.saveAllVisiblePages()
                Profiles(requireContext()).switchTo(bound.id)
                prefs.voice = picked
                host.restartForProfile(getString(R.string.profile_switched, bound.name))
                return@setOnItemClickListener
            }
            shown = voiceView.str()
            // голос прямой речи другого движка не трогаем: сервис читает реплики основным (takeIf по паку),
            // вернули движок — прямая речь снова своим голосом
            voiceKept = false; voiceView.missing(null, ""); picked?.let { voiceView.bound(it) }
        }
        v.dropdown(R.id.sampleRate, rateItems, rateItems[rates.indexOf(prefs.sampleRate).coerceAtLeast(0)])
        v.rateSlider(R.id.rate, R.id.rateValue, prefs.rate, getString(R.string.quote_rate))
        v.rateSlider(R.id.pitch, R.id.pitchValue, prefs.pitch, getString(R.string.quote_pitch))
        v.rateSlider(R.id.volume, R.id.volumeValue, prefs.volume, getString(R.string.volume), to = 3f)
        v.findViewById<Button>(R.id.sysTtsSettings).setOnClickListener { requireContext().openSysTtsSettings(v) }

        // Дополнительная модель RUAccent скачивается один раз. Сам инференс полностью локальный;
        // в TTS-конвейер она включается автоматически для русского слоя.
        val ruAccentInstaller = ru.kost.ruvoice.text.RuAccentModelInstaller(requireContext())
        val ruAccentButton = v.findViewById<Button>(R.id.ruAccentInstall)
        val ruAccentStatus = v.findViewById<TextView>(R.id.ruAccentStatus)
        fun showRuAccentInstalled() {
            ruAccentStatus.setText(R.string.ruaccent_installed)
            ruAccentButton.isEnabled = false
            ruAccentButton.setText(R.string.ruaccent_installed_button)
        }
        if (ruAccentInstaller.installedDirectory() != null) {
            // Model files and both native runtimes must be present before we show the feature as active.
            if (SileroModels.shared(requireContext()).refreshIndependentStressCorrector()) {
                showRuAccentInstalled()
            } else {
                ruAccentStatus.setText(R.string.ruaccent_activation_error)
                ruAccentButton.isEnabled = true
            }
        }
        ruAccentButton.setOnClickListener {
            ruAccentButton.isEnabled = false
            ruAccentStatus.setText(R.string.ruaccent_starting_download)
            val appContext = requireContext().applicationContext
            val host = activity
            Thread({
                try {
                    var lastFileIndex = 0
                    var lastBytes = 0L
                    ruAccentInstaller.install { progress ->
                        if (progress.fileIndex != lastFileIndex || progress.bytesRead - lastBytes >= 4L * 1024L * 1024L) {
                            lastFileIndex = progress.fileIndex
                            lastBytes = progress.bytesRead
                            host?.runOnUiThread {
                                if (isAdded) ruAccentStatus.text = getString(
                                    R.string.ruaccent_downloading,
                                    progress.fileIndex,
                                    progress.fileCount,
                                    progress.fileName,
                                )
                            }
                        }
                    }
                    val activated = SileroModels.shared(appContext).refreshIndependentStressCorrector(warmUp = true)
                    host?.runOnUiThread {
                        if (isAdded) {
                            if (activated) {
                                ruAccentStatus.setText(R.string.ruaccent_download_done)
                                ruAccentButton.setText(R.string.ruaccent_installed_button)
                                ruAccentButton.isEnabled = false
                            } else {
                                ruAccentStatus.setText(R.string.ruaccent_activation_error)
                                ruAccentButton.isEnabled = true
                            }
                        }
                    }
                } catch (error: Throwable) {
                    host?.runOnUiThread {
                        if (isAdded) {
                            ruAccentStatus.text = getString(
                                R.string.ruaccent_download_error,
                                error.localizedMessage ?: error.javaClass.simpleName,
                            )
                            ruAccentButton.isEnabled = true
                        }
                    }
                }
            }, "ruvoice-ruaccent-install").apply { isDaemon = true; start() }
        }

        v.findViewById<TextView>(R.id.setupHelp).apply {
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG // иначе сливается с подписями ниже
            setOnClickListener { (activity as? SettingsActivity)?.showSetupHelp() }
        }
        val previewText = v.findViewById<EditText>(R.id.previewText)
        if (previewText.text.isEmpty()) previewText.setText(prefs.previewText.ifEmpty { getString(R.string.preview_text) })

        v.findViewById<Button>(R.id.preview).setOnClickListener { btn ->
            if (voices.isEmpty()) return@setOnClickListener
            save(v)
            (activity as SettingsActivity).preview(btn, previewText.str().ifBlank { getString(R.string.preview_text) })
        }
        v.findViewById<Button>(R.id.analyze).setOnClickListener {
            if (voices.isEmpty()) return@setOnClickListener
            save(v)
            (activity as SettingsActivity).analyze(previewText.str().ifBlank { getString(R.string.preview_text) })
        }
    }

    override fun save(v: View) {
        val main = nameOf(v.findViewById<TextView>(R.id.voice).str()) ?: prefs.voice
        if (main in voices && !voiceKept) prefs.voice = main
        rateItems.indexOf(v.findViewById<TextView>(R.id.sampleRate).str()).let { if (it >= 0) prefs.sampleRate = rates[it] }
        prefs.rate = v.findViewById<Slider>(R.id.rate).value
        prefs.pitch = v.findViewById<Slider>(R.id.pitch).value
        prefs.volume = v.findViewById<Slider>(R.id.volume).value
        prefs.previewText = v.findViewById<EditText>(R.id.previewText).str()
    }

    private fun TextView.str() = text.toString()

    /** Подпись под выпадашкой: голоса [name] нет на телефоне, читает [shown]; null — убрать подпись. */
    private fun View.missing(name: String?, shown: String) = helper(name?.let { getString(R.string.voice_missing, Speaker.label(it), shown) })

    /** Подпись под голосом: к какому профилю он привязан (Profiles.bind) — выбор такого голоса включает тот профиль. */
    private fun View.bound(voice: String) {
        val profiles = Profiles(requireContext())
        val p = profiles.binds()[voice]?.let { id -> profiles.list().firstOrNull { it.id == id } } ?: return
        helper(getString(if (p.id == profiles.active().id) R.string.voice_bound_this else R.string.voice_bound, p.name))
    }

    // Системные темп/высота (Settings.Secure, 100 = ×1) — только показать: запись требует
    // WRITE_SECURE_SETTINGS, которое обычному приложению не выдают. Обновляем при возврате
    // с системного экрана (onResume).
    override fun onResume() {
        super.onResume()
        val cr = requireContext().contentResolver
        fun read(key: String) = "%.2f".format(Locale.ROOT, Settings.Secure.getInt(cr, key, 100) / 100f)
        view?.findViewById<TextView>(R.id.sysValues)?.text =
            getString(R.string.sys_values, read("tts_default_rate"), read("tts_default_pitch"))
        // привязку могли поменять на вкладке «Профили» — подпись под голосом заново
        val voiceView = view?.findViewById<TextView>(R.id.voice) ?: return
        if (voiceKept) return
        voiceView.missing(null, "")
        nameOf(voiceView.str())?.let { voiceView.bound(it) }
    }

}

/** Паузы и выгрузка моделей. */
class PausesFragment : PageFragment(R.layout.fragment_pauses) {
    override fun load(v: View) {
        v.findViewById<EditText>(R.id.pauseSentence).setText(prefs.sentencePauseMs.toString())
        v.findViewById<EditText>(R.id.pauseParagraph).setText(prefs.paragraphPauseMs.toString())
        v.findViewById<EditText>(R.id.pauseComma).setText(prefs.commaPauseMs.toString())
        v.findViewById<EditText>(R.id.pauseDash).setText(prefs.dashPauseMs.toString())
        v.findViewById<EditText>(R.id.idleMinutes).setText(prefs.idleMinutes.toString())
        val minutes = v.findViewById<View>(R.id.idleMinutesLayout)
        v.findViewById<MaterialSwitch>(R.id.idleOn).apply {
            isChecked = prefs.idleOn
            minutes.visibility = if (isChecked) View.VISIBLE else View.GONE
            setOnCheckedChangeListener { _, on -> minutes.visibility = if (on) View.VISIBLE else View.GONE }
        }
        // «Не выгружать, пока работает экранный чтец» — то же правило, что в «Чтение с экрана»: пишем сразу,
        // save() его не трогает — иначе старое значение вкладки затёрло бы правку с экрана правил
        v.findViewById<MaterialSwitch>(R.id.srKeepLoaded).apply { isChecked = Rules(prefs.rulesOff).on("sr_keep_loaded") }.setOnCheckedChangeListener { sw, on -> if (sw.tag !== SYNC) prefs.setRule("sr_keep_loaded", on) }
    }

    // экран правил мог переключить то же правило, пока вкладка стояла в фоне
    override fun onResume() {
        super.onResume()
        view?.findViewById<MaterialSwitch>(R.id.srKeepLoaded)?.let { sw ->
            val on = Rules(prefs.rulesOff).on("sr_keep_loaded")
            if (sw.isChecked != on) { sw.tag = SYNC; sw.isChecked = on; sw.tag = null }
        }
    }

    override fun save(v: View) {
        prefs.sentencePauseMs = v.int(R.id.pauseSentence, 0).coerceAtLeast(0)
        prefs.paragraphPauseMs = v.int(R.id.pauseParagraph, 300).coerceAtLeast(0)
        prefs.commaPauseMs = v.int(R.id.pauseComma, 100).coerceAtLeast(0)
        prefs.dashPauseMs = v.int(R.id.pauseDash, 150).coerceAtLeast(0)
        prefs.idleMinutes = v.int(R.id.idleMinutes, 5).coerceAtLeast(1)
        prefs.idleOn = v.findViewById<MaterialSwitch>(R.id.idleOn).isChecked
    }

    private fun View.int(id: Int, default: Int) = findViewById<EditText>(id).str().toIntOrNull() ?: default

    private companion object { val SYNC = Any() }
}

/** Тумблеры правил обработки текста (Rules.KEYS) и длина куска. */
class RulesFragment : PageFragment(R.layout.fragment_rules) {
    private fun res(name: String) = resources.getIdentifier(name, "string", requireContext().packageName)

    /** Строка списка для поиска: заголовок секции ([text] пустой) или правило/блок под ним с текстом. */
    private class Entry(val view: View, val text: String, val group: Int, val header: Boolean)
    private val entries = ArrayList<Entry>()
    /** Страница «Английский» из меню ⋮ — только секция english; в «Настройках» её нет. */
    private val english get() = arguments?.getBoolean(ARG_ENGLISH) == true
    /** Тумблеры этой страницы: остальные ключи rulesOff сохраняются как были. */
    private val shownKeys = HashSet<String>()
    /** Язык вкладки (код пака): какие правила видны и чьи подсказки. Нигде не хранится — при открытии язык голоса. */
    private var lang = "ru"
    /** Вкладка до пересоздания окна (поворот): та же, а не снова язык голоса. */
    private var savedLang: String? = null

    override fun onCreate(state: Bundle?) { super.onCreate(state); savedLang = state?.getString(KEY_LANG) }
    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); out.putString(KEY_LANG, lang) }

    override fun load(v: View) {
        if (!english) loadTabs(v)
        // при вкладках общая подпись остаётся: пояснение про языки — над поиском, совет про «Разбор» — под ним
        for (id in listOf(R.id.chunkBlock, R.id.rulesFilterBox, R.id.rulesHint)) v.findViewById<View>(id).visibility = if (english) View.GONE else View.VISIBLE
        v.findViewById<EditText>(R.id.maxLen).setText(prefs.maxLen.toString())
        v.findViewById<EditText>(R.id.srMaxLen).setText(prefs.srMaxLen.toString())
        v.findViewById<View>(R.id.quoteBlock).visibility = if (english) View.GONE else View.VISIBLE
        if (!english) loadQuote(v)
        // слушатель — один на окно: fill() при смене вкладки его не добавляет
        v.findViewById<EditText>(R.id.rulesFilter).doAfterTextChanged { filter(v, it?.toString().orEmpty()) }
        fill(v)
    }

    /** Вкладки языков голосов, установленных на телефоне, — только если языков два и больше: иначе экран прежний,
     * а правила — языка голоса. Выбрана вкладка языка текущего голоса. true — вкладки показаны. */
    private fun loadTabs(v: View): Boolean {
        val builtin = SileroModels.speakers(v.context)
        val langs = Speaker.langs(builtin, packs)
        lang = savedLang?.takeIf { langs.size > 1 && it in langs }
            ?: Speaker.currentName(prefs.voice, builtin, packs)?.let { Speaker.lang(it, packs) } ?: "ru"
        if (langs.size < 2) return false
        v.findViewById<View>(R.id.rulesLangHint).visibility = View.VISIBLE
        v.findViewById<TabLayout>(R.id.rulesTabs).apply {
            visibility = View.VISIBLE
            for (code in langs) addTab(newTab().setText(langLabel(code)).setTag(code), code == lang)
            // до перестройки — сохранить тумблеры прежней вкладки; фокус остаётся на вкладке, TalkBack скажет «выбрано»
            addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) { saveNow(); lang = tab.tag as String; fill(v) }
                override fun onTabUnselected(tab: TabLayout.Tab) {}
                override fun onTabReselected(tab: TabLayout.Tab) {}
            })
        }
        return true
    }

    /** «Русские голоса», «Белорусские голоса»; языку без своей строки — название языка. */
    private fun langLabel(code: String): String = res("rules_lang_$code").takeIf { it != 0 }?.let(::getString)
        ?: requireContext().uiLocale.let { ui -> Locale(code).getDisplayLanguage(ui).replaceFirstChar { it.titlecase(ui) } }

    /** Подпись правила на вкладке: своя для языка (rule_<key>_hint_be — примеры по-белорусски), иначе общая. LocaleSpan
     * на примерах нет: TalkBack попросил бы белорусский голос и перегружал модель на каждой подписи. */
    private fun hint(key: String) = res("rule_${key}_hint_$lang").takeIf { it != 0 } ?: res("rule_${key}_hint")

    /** Список правил вкладки [lang] заново (Rules.rows): заголовок раздела — над первой видимой строкой. */
    private fun fill(v: View) {
        val list = v.findViewById<LinearLayout>(R.id.rulesList)
        list.removeAllViews()
        entries.clear()
        shownKeys.clear()
        var group = -1
        val rules = Rules(prefs.rulesOff)
        val inflater = LayoutInflater.from(v.context)
        for ((key, head) in Rules.rows(Layers.of(lang), english)) {
            shownKeys += key
            head?.let { section ->
                val header = TextView(v.context, null, 0, R.style.Section).apply { setText(res("rules_section_$section")); asHeading() }
                list.addView(header,
                    LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                        .apply { topMargin = if (list.childCount == 0) 0 else (24 * resources.displayMetrics.density).toInt() })
                group++
                entries += Entry(header, header.text.toString(), group, true)
                // под «Чтение с экрана (TalkBack)» — какие программы это; в поиске ведёт себя как заголовок
                if (section == "talkback") {
                    val hint = TextView(v.context, null, 0, R.style.SectionHint).apply { setText(R.string.rules_section_talkback_hint) }
                    list.addView(hint)
                    entries += Entry(hint, hint.text.toString(), group, true)
                }
            }
            val row = inflater.inflate(R.layout.item_rule, list, false)
            row.findViewById<TextView>(R.id.title).setText(res("rule_$key"))
            row.findViewById<TextView>(R.id.hint).setText(hint(key))
            val rowText = getString(res("rule_$key")) + " " + getString(hint(key))
            fun extra(block: View, text: String) { list.addView(block); entries += Entry(block, "$rowText $text", group, false) }
            val toggle = row.findViewById<MaterialSwitch>(R.id.toggle)
            toggle.tag = key
            toggle.isChecked = rules.on(key)
            row.asSwitchRow(toggle)
            list.addView(row)
            entries += Entry(row, rowText, group, false)
            // под правилами «Чтение с экрана» — темп и высота чтеца и кто обращался к движку
            if (key == "sr_keep_loaded") {
                extra(inflater.inflate(R.layout.item_sr_sliders, list, false).apply {
                    rateSlider(R.id.srRate, R.id.srRateValue, prefs.srRate, getString(R.string.sr_rate))
                    rateSlider(R.id.srPitch, R.id.srPitchValue, prefs.srPitch, getString(R.string.sr_pitch))
                    rateSlider(R.id.srVolume, R.id.srVolumeValue, prefs.srVolume, getString(R.string.sr_volume))
                }, getString(R.string.sr_rate) + " " + getString(R.string.sr_pitch) + " " + getString(R.string.sr_volume) + " " + getString(R.string.sr_sliders_hint))
                extra(callersBlock(inflater, list), getString(R.string.callers_title) + " " + getString(R.string.callers_hint) + " " + prefs.recentCallers().joinToString(" ") { it.first.label + " " + it.first.pkg })
            }
            // английский другим движком: при включении — предупреждение; под каждым тумблером — свой порог слов,
            // под последним — движок, голос, темп и громкость (общие)
            if (key == "en_proxy_books" || key == "en_proxy_sr") {
                toggle.setOnCheckedChangeListener { _, on -> if (on) confirmEnglish(toggle) }
                val sr = key == "en_proxy_sr"
                val hintText = getString(if (sr) R.string.en_min_words_sr_hint else R.string.en_min_words_hint)
                extra(inflater.inflate(R.layout.item_en_words, list, false).apply {
                    findViewById<TextView>(R.id.enWordsHint).text = hintText
                    if (sr) findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.enMinWordsLayout).setHint(R.string.en_min_words_sr)
                    findViewById<EditText>(R.id.enMinWords).apply {
                        if (sr) id = R.id.enMinWordsSr
                        setText((if (sr) prefs.enMinWordsSr else prefs.enMinWords).toString())
                    }
                }, getString(if (sr) R.string.en_min_words_sr else R.string.en_min_words) + " " + hintText)
                if (sr) extra(inflater.inflate(R.layout.item_en_timeout, list, false).apply {
                    findViewById<EditText>(R.id.enSrTimeout).setText(prefs.enSrTimeoutMs.toString())
                }, getString(R.string.en_sr_timeout) + " " + getString(R.string.en_sr_timeout_hint))
            }
            if (key == "en_proxy_sr") {
                val voiceRow = voiceRow(inflater, list)
                val engineRow = engineRow(inflater, list) { offline = null; describeVoice(voiceRow); checkOffline(voiceRow) }
                refreshEnglish = { offline = null; describeEngine(engineRow); describeVoice(voiceRow); checkOffline(voiceRow) }
                extra(engineRow, getString(R.string.en_engine))
                extra(voiceRow, getString(R.string.en_voice))
                extra(inflater.inflate(R.layout.item_en_sliders, list, false).apply {
                    rateSlider(R.id.enRate, R.id.enRateValue, prefs.enRate, getString(R.string.en_rate))
                    rateSlider(R.id.enVolume, R.id.enVolumeValue, prefs.enVolume, getString(R.string.en_volume))
                }, getString(R.string.en_rate) + " " + getString(R.string.en_volume) + " " + getString(R.string.en_sliders_hint))
                checkOffline(voiceRow)
            }
            // поле силы ударения — сразу под своим тумблером
            if (key == "focus") extra(inflater.inflate(R.layout.item_focus_level, list, false).apply {
                findViewById<EditText>(R.id.focusLevel).setText(prefs.focusLevel.toString())
            }, getString(R.string.focus_level) + " " + getString(R.string.focus_level_hint))
        }
        if (!english) {
            // в поиске — своя секция: заголовок с подписью и сами настройки
            group++
            entries += Entry(v.findViewById(R.id.quoteHead), getString(R.string.section_quote), group, true)
            entries += Entry(v.findViewById(R.id.quoteBody), listOf(R.string.section_quote_hint, R.string.quote_on, R.string.quote_voice,
                R.string.quote_rate_a11y, R.string.quote_pitch_a11y).joinToString(" ") { getString(it) }, group, false)
        }
        // поиск — внутри вкладки; «Найдено N» живой области обновится и на новой вкладке
        filter(v, v.findViewById<EditText>(R.id.rulesFilter).text.toString())
    }

    // Прямая речь (перенесена с вкладки «Голос»): голос из того же движка, что основной (prefs.voice —
    // вкладка «Голос» сохранила его в onPause до открытия этого окна).
    private val d by lazy { SileroModels.data(requireContext()) }
    private val packs by lazy { Packs.installed(requireContext().filesDir) }
    /** Голоса prefs.quoteVoice нет в списке (пак удалили или он другого движка, чем основной): сервис читает
     * реплики основным голосом, а выбор в prefs остаётся, пока голос не выберут здесь сами. */
    private var quoteKept = false

    /** Голоса движка основного голоса (Speaker.sameEngine), в выпадашке после «как основной»; пусто без голосов (lite до пака). */
    private fun quoteVoices(): List<String> {
        val main = Speaker.resolve(prefs.voice, d, packs) ?: Speaker.default(d, packs) ?: return emptyList()
        return Speaker.sameEngine(main, d, packs)
    }

    private fun loadQuote(v: View) {
        val voices = quoteVoices()
        val items = listOf(getString(R.string.quote_voice_default)) + voices.map { Speaker.label(it) }
        val stored = Speaker.resolve(prefs.quoteVoice, d, packs)
        val shown = stored?.name?.takeIf { it in voices }?.let(Speaker::label) ?: items.first()
        val quoteView = v.dropdown(R.id.quoteVoice, items, shown)
        quoteKept = voices.isNotEmpty() && prefs.quoteVoice.isNotEmpty() && stored?.name !in voices
        quoteView.helper(if (!quoteKept) null else if (stored == null) getString(R.string.voice_missing, Speaker.label(prefs.quoteVoice), shown)
            else getString(R.string.quote_voice_other_engine, Speaker.label(stored.name)))
        quoteView.setOnItemClickListener { _, _, _, _ -> quoteKept = false; quoteView.helper(null) }
        v.rateSlider(R.id.quoteRate, R.id.quoteRateValue, prefs.quoteRate, getString(R.string.quote_rate_a11y))
        v.rateSlider(R.id.quotePitch, R.id.quotePitchValue, prefs.quotePitch, getString(R.string.quote_pitch_a11y))
        // голос, темп и высота видны только при включённом распознавании
        val quoteGroup = v.findViewById<View>(R.id.quoteGroup)
        v.findViewById<MaterialSwitch>(R.id.quoteOn).apply {
            isChecked = prefs.quoteOn
            quoteGroup.visibility = if (isChecked) View.VISIBLE else View.GONE
            setOnCheckedChangeListener { _, on -> quoteGroup.visibility = if (on) View.VISIBLE else View.GONE }
        }
    }

    private fun saveQuote(v: View) {
        val voices = quoteVoices()
        val label = v.findViewById<TextView>(R.id.quoteVoice).text.toString()
        // без голосов (lite до пака) выпадашка пустая — не затирать голос прямой речи из prefs
        if (voices.isNotEmpty() && !quoteKept) prefs.quoteVoice = voices.firstOrNull { Speaker.label(it) == label } ?: ""
        prefs.quoteRate = v.findViewById<Slider>(R.id.quoteRate).value
        prefs.quotePitch = v.findViewById<Slider>(R.id.quotePitch).value
        prefs.quoteOn = v.findViewById<MaterialSwitch>(R.id.quoteOn).isChecked
    }

    /** Поиск: правило видно, если в названии или подписи есть все слова запроса; заголовок — если
     * виден хоть один пункт секции или совпало само имя секции (тогда видна вся секция). */
    private fun filter(v: View, query: String) {
        val words = query.lowercase().split(' ').filter { it.isNotBlank() }
        fun hit(text: String) = text.lowercase().let { t -> words.all { it in t } }
        val found = v.findViewById<TextView>(R.id.rulesFound)
        if (words.isEmpty()) {
            for (e in entries) e.view.visibility = View.VISIBLE
            found.visibility = View.GONE
            return
        }
        val wholeGroups = entries.filter { it.header && hit(it.text) }.map { it.group }.toSet()
        var count = 0
        for (e in entries) if (!e.header) {
            val show = e.group in wholeGroups || hit(e.text)
            e.view.visibility = if (show) View.VISIBLE else View.GONE
            if (show) count++
        }
        for (e in entries) if (e.header)
            e.view.visibility = if (entries.any { !it.header && it.group == e.group && it.view.visibility == View.VISIBLE }) View.VISIBLE else View.GONE
        found.visibility = View.VISIBLE
        found.text = if (count == 0) getString(R.string.rules_found_none) else resources.getQuantityString(R.plurals.rules_found, count, count)
    }

    /** «Кто читает через движок»: последние отправители запросов, у каждого тумблер «экранный чтец».
     * По умолчанию — как решила автоматика (ScreenReaders), переключение запоминается для пакета.
     * В рамке и со своим заголовком: глазами видно, что строки — не правила, TalkBack доходит жестом «заголовки». */
    private fun callersBlock(inflater: LayoutInflater, parent: LinearLayout): View {
        val ctx = parent.context
        val dp = resources.displayMetrics.density
        val card = MaterialCardView(ctx, null, com.google.android.material.R.attr.materialCardViewOutlinedStyle).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = (16 * dp).toInt(); bottomMargin = (8 * dp).toInt() }
        }
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; val p = (16 * dp).toInt(); setPadding(p, p, p, p / 2) }
        card.addView(box)
        box.addView(TextView(ctx, null, 0, R.style.Section).apply { setText(R.string.callers_title); asHeading() },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(TextView(ctx, null, 0, R.style.SectionHint).apply { setText(R.string.callers_hint) })
        val callers = prefs.recentCallers()
        if (callers.isEmpty()) box.addView(TextView(ctx, null, 0, R.style.SectionHint).apply { setText(R.string.callers_empty) })
        for ((c, _) in callers) {
            val row = inflater.inflate(R.layout.item_rule, box, false)
            val hint = row.findViewById<TextView>(R.id.hint)
            val toggle = row.findViewById<MaterialSwitch>(R.id.toggle)
            row.findViewById<TextView>(R.id.title).text = c.label
            fun describe() {
                hint.text = getString(when {
                    c.pkg in prefs.srForce -> R.string.caller_manual_sr
                    c.pkg in prefs.srNever -> R.string.caller_manual_app
                    c.auto -> R.string.caller_auto_sr
                    else -> R.string.caller_auto_app
                }, c.pkg)
            }
            toggle.isChecked = ScreenReaders.isScreenReader(prefs, c)
            describe()
            toggle.setOnCheckedChangeListener { _, on ->
                prefs.srForce = if (on && !c.auto) prefs.srForce + c.pkg else prefs.srForce - c.pkg
                prefs.srNever = if (!on && c.auto) prefs.srNever + c.pkg else prefs.srNever - c.pkg
                describe()
            }
            row.asSwitchRow(toggle)
            box.addView(row)
        }
        return card
    }

    /** Включили «Английский другим движком» — спокойно объясняем, куда уйдёт текст. «Отмена» или
     * закрытие окна тумблер возвращают; без других движков включать нечего. */
    private fun confirmEnglish(toggle: MaterialSwitch) {
        EnglishProxy.forget()
        val engine = EnglishProxy.suggest(requireContext(), prefs.enEngine)
        if (engine == null) {
            toggle.isChecked = false
            MaterialAlertDialogBuilder(requireContext()).setTitle(R.string.en_proxy_confirm_title)
                .setMessage(R.string.en_engine_none).setPositiveButton(R.string.close, null).show()
            return
        }
        var accepted = false
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.en_proxy_confirm_title)
            .setMessage(getString(R.string.en_proxy_confirm, engine.label))
            .setPositiveButton(R.string.en_proxy_enable) { _, _ ->
                accepted = true
                // согласие — на этот движок: его и запоминаем, на другой сервис молча не перейдёт
                if (prefs.enEngine != engine.pkg) { prefs.enEngine = engine.pkg; prefs.enVoice = "" }
                refreshEnglish()
            }
            .setNegativeButton(R.string.cancel, null)
            .setOnDismissListener { if (!accepted) toggle.isChecked = false }
            .show()
    }

    /** Строка выбора без тумблера («Движок…», «Голос…»): для TalkBack — кнопка с названием и значением.
     * Подпись со значением — живая область: сменили движок или голос, ждём список — чтец скажет сам,
     * фокус остаётся на строке. */
    private fun pickerRow(inflater: LayoutInflater, parent: LinearLayout, title: Int, pickLabel: Int): View =
        inflater.inflate(R.layout.item_picker, parent, false).apply {
            findViewById<TextView>(R.id.title).setText(title)
            ViewCompat.setAccessibilityLiveRegion(findViewById(R.id.hint), ViewCompat.ACCESSIBILITY_LIVE_REGION_POLITE)
            isFocusable = true
            ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {
                override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                    super.onInitializeAccessibilityNodeInfo(host, info)
                    info.className = Button::class.java.name
                }
            })
            clickLabel(getString(pickLabel))
        }

    private fun message(title: Int, text: String) =
        MaterialAlertDialogBuilder(requireContext()).setTitle(title).setMessage(text).setPositiveButton(R.string.close, null).show()

    /** Строка «Голос для английского»: голоса движка грузятся в фоне (клиент подключается до пяти секунд). */
    private fun voiceRow(inflater: LayoutInflater, parent: LinearLayout): View {
        val row = pickerRow(inflater, parent, R.string.en_voice, R.string.en_voice_pick)
        describeVoice(row)
        var loading = false
        row.setOnClickListener {
            if (loading) return@setOnClickListener
            val ctx = requireContext().applicationContext
            val engine = EnglishProxy.chosen(ctx, prefs.enEngine)
                ?: return@setOnClickListener message(R.string.en_voice, getString(R.string.en_voice_no_engine)).let { }
            val hint = row.findViewById<TextView>(R.id.hint)
            hint.setText(R.string.en_voice_loading)
            loading = true
            Thread {
                // свой клиент: общий сервиса может быть занят чтением, окно ждало бы, пока дочитает
                val voices = EnglishProxy.create(ctx).let { p -> try { p.voices(engine.pkg) } finally { p.release() } }
                if (voices != null) { offline = voices.any { it.offline }; enVoiceMissing = gone(voices) }
                activity?.runOnUiThread {
                    loading = false
                    if (!isAdded) return@runOnUiThread
                    describeVoice(row)
                    if (voices.isNullOrEmpty()) {
                        message(R.string.en_voice, getString(R.string.en_voice_none, engine.label))
                        return@runOnUiThread
                    }
                    val labels = listOf(getString(R.string.en_voice_default)) + voices.map { voiceLabel(it) }
                    var picked = voices.indexOfFirst { it.name == prefs.enVoice } + 1
                    // ползунки ещё не сохранены (Prefs пишутся в onPause) — берём с экрана
                    val sample = EnglishSample(ctx, engine.pkg, voices, view?.findViewById<Slider>(R.id.enRate)?.value ?: prefs.enRate,
                        view?.findViewById<Slider>(R.id.enVolume)?.value ?: prefs.enVolume)
                    // с чтецом образец сам не играет — перебил бы «выбрано»; для этого кнопка «Прослушать»
                    val auto = !ScreenReaders.anyActive(ctx)
                    MaterialAlertDialogBuilder(requireContext())
                        .setTitle(R.string.en_voice)
                        .setSingleChoiceItems(labels.toTypedArray(), picked) { _, i -> picked = i; if (auto) sample.play(i) }
                        .setPositiveButton(R.string.en_voice_choose) { _, _ ->
                            prefs.enVoice = if (picked == 0) "" else voices[picked - 1].name; enVoiceMissing = false; describeVoice(row)
                        }
                        .setNeutralButton(R.string.preview, null)
                        .setNegativeButton(R.string.cancel, null)
                        .setOnDismissListener { sample.release() }
                        .show()
                        // нейтральная кнопка по умолчанию закрывает окно — здесь она только играет
                        .getButton(android.content.DialogInterface.BUTTON_NEUTRAL).setOnClickListener { sample.play(picked) }
                }
            }.start()
        }
        return row
    }

    /** Пункт списка голосов словами, без «·» и без технического имени целиком: «Английский (США), голос iol,
     * нужен интернет». Имя вида en-us-x-iol-local TalkBack читал бы по кускам. */
    private fun voiceLabel(v: EnglishProxy.VoiceInfo): String =
        listOfNotNull(EnglishProxy.voiceTitle(v.name, v.locale, requireContext().uiLocale, getString(R.string.en_voice_word)),
            getString(R.string.en_voice_network).takeIf { v.network },
            getString(R.string.en_voice_not_installed).takeIf { !v.installed }).joinToString(", ")

    /** Есть ли у выбранного движка офлайн-голос для английского: null — ещё не знаем. */
    @Volatile private var offline: Boolean? = null
    /** Голоса из prefs.enVoice у движка нет (удалили, профиль или файл с другого телефона): сервис читает
     * голосом по умолчанию (EnglishProxy.applyVoice), строка говорит об этом прямо. */
    @Volatile private var enVoiceMissing = false
    private var refreshEnglish: () -> Unit = {}

    /** Голос по умолчанию сервис берёт офлайн (EnglishProxy.pickOffline); если офлайн-голосов нет — прямо
     * в строке предупреждаем, что текст может уходить в интернет. */
    private fun describeVoice(row: View) {
        row.findViewById<TextView>(R.id.hint).text = if (prefs.enVoice.isNotEmpty() && enVoiceMissing)
            getString(R.string.en_voice_missing, EnglishProxy.voiceTitle(prefs.enVoice, null, requireContext().uiLocale, getString(R.string.en_voice_word)))
        else if (prefs.enVoice.isNotEmpty())
            getString(R.string.en_voice_value, EnglishProxy.voiceTitle(prefs.enVoice, null, requireContext().uiLocale, getString(R.string.en_voice_word)))
        else when (offline) {
            false -> getString(R.string.en_voice_default_online)
            true -> getString(R.string.en_voice_default_offline)
            null -> getString(R.string.en_voice_default)
        }
    }

    /** Узнать в фоне, есть ли офлайн-голос, — только если английский включён и движок выбран: иначе
     * подключаться к чужому движку незачем. */
    private fun checkOffline(row: View) {
        val ctx = requireContext().applicationContext
        val rules = Rules(prefs.rulesOff)
        if (!rules.on("en_proxy_books") && !rules.on("en_proxy_sr")) return
        val engine = EnglishProxy.chosen(ctx, prefs.enEngine) ?: return
        Thread {
            val voices = EnglishProxy.create(ctx).let { p -> try { p.voices(engine.pkg) } finally { p.release() } } ?: return@Thread
            offline = voices.any { it.offline }; enVoiceMissing = gone(voices)
            activity?.runOnUiThread { if (isAdded) describeVoice(row) }
        }.start()
    }

    private fun gone(voices: List<EnglishProxy.VoiceInfo>) = prefs.enVoice.isNotEmpty() && voices.none { it.name == prefs.enVoice }

    /** Выбранный движок; удалили — говорим прямо, что английский сейчас читается по-русски. */
    private fun describeEngine(row: View) {
        val e = EnglishProxy.chosen(requireContext(), prefs.enEngine)
        row.findViewById<TextView>(R.id.hint).text = when {
            e != null -> getString(R.string.en_engine_value, e.label)
            EnglishProxy.engines(requireContext()).isEmpty() -> getString(R.string.en_engine_none)
            prefs.enEngine.isNotEmpty() -> getString(R.string.en_engine_missing)
            else -> getString(R.string.en_engine_not_chosen)
        }
    }

    /** Строка «Движок для английского»: какой сейчас и выбор из установленных. */
    private fun engineRow(inflater: LayoutInflater, parent: LinearLayout, onChange: () -> Unit): View {
        val row = pickerRow(inflater, parent, R.string.en_engine, R.string.en_engine_pick)
        describeEngine(row)
        row.setOnClickListener {
            EnglishProxy.forget()
            val engines = EnglishProxy.engines(requireContext())
            if (engines.isEmpty()) { describeEngine(row); message(R.string.en_engine, getString(R.string.en_engine_none)); return@setOnClickListener }
            val cur = EnglishProxy.chosen(requireContext(), prefs.enEngine)
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.en_engine)
                .setSingleChoiceItems(engines.map { it.label }.toTypedArray(), engines.indexOfFirst { it.pkg == cur?.pkg }) { d, i ->
                    // голос прежнего движка новому не подходит, про офлайн-голоса ещё не знаем
                    if (prefs.enEngine != engines[i].pkg) prefs.enVoice = ""
                    prefs.enEngine = engines[i].pkg; describeEngine(row); onChange(); d.dismiss()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
        return row
    }

    override fun save(v: View) {
        val list = v.findViewById<LinearLayout>(R.id.rulesList)
        // тумблеры правил помечены ключом; у строк «Кто читает через движок» тега нет
        prefs.rulesOff = prefs.rulesOff.filterTo(HashSet()) { it !in shownKeys } +
            (0 until list.childCount).mapNotNull { list.getChildAt(it).findViewById<MaterialSwitch>(R.id.toggle) }
            .filter { it.tag is String }
            .filter { it.isChecked == (it.tag in Rules.DEFAULT_OFF) }.map { it.tag as String }
        if (!english) prefs.maxLen = (v.findViewById<EditText>(R.id.maxLen).str().toIntOrNull() ?: Rules.MAX_LEN_DEFAULT)
            .coerceIn(Rules.MAX_LEN_MIN, Rules.MAX_LEN_MAX)
        if (!english) saveQuote(v)
        if (!english) prefs.srMaxLen = (v.findViewById<EditText>(R.id.srMaxLen).str().toIntOrNull() ?: Rules.SR_MAX_LEN_DEFAULT)
            .coerceIn(Rules.MAX_LEN_MIN, Rules.MAX_LEN_MAX)
        v.findViewById<Slider>(R.id.srRate)?.let { prefs.srRate = it.value }
        v.findViewById<Slider>(R.id.srPitch)?.let { prefs.srPitch = it.value }
        v.findViewById<Slider>(R.id.srVolume)?.let { prefs.srVolume = it.value }
        v.findViewById<EditText>(R.id.enMinWords)?.let { prefs.enMinWords = (it.str().toIntOrNull() ?: English.MIN_WORDS).coerceIn(English.MIN_WORDS, English.MAX_WORDS) }
        v.findViewById<EditText>(R.id.enMinWordsSr)?.let { prefs.enMinWordsSr = (it.str().toIntOrNull() ?: English.MIN_WORDS).coerceIn(English.MIN_WORDS, English.MAX_WORDS) }
        v.findViewById<EditText>(R.id.enSrTimeout)?.let {
            prefs.enSrTimeoutMs = (it.str().toIntOrNull() ?: EnglishProxy.SR_TIMEOUT_DEFAULT).coerceIn(EnglishProxy.SR_TIMEOUT_MIN, EnglishProxy.SR_TIMEOUT_MAX)
        }
        v.findViewById<Slider>(R.id.enRate)?.let { prefs.enRate = it.value }
        v.findViewById<Slider>(R.id.enVolume)?.let { prefs.enVolume = it.value }
        v.findViewById<EditText>(R.id.focusLevel)?.let { prefs.focusLevel = (it.str().toIntOrNull() ?: Rules.FOCUS_DEFAULT)
            .coerceIn(Rules.FOCUS_MIN, Rules.FOCUS_MAX) }
    }

    companion object {
        const val ARG_ENGLISH = "english"
        private const val KEY_LANG = "rules_lang"
    }
}

/** Образец английского голоса в окне выбора: свой клиент к движку [pkg], пункт 0 — «по умолчанию»
 * (офлайн-голос, как у сервиса), остальные — [voices] по порядку. Темп и громкость — поправки для английского. */
private class EnglishSample(private val ctx: android.content.Context, pkg: String, private val voices: List<EnglishProxy.VoiceInfo>,
                            private val rate: Float, private val volume: Float) {
    private var ready = false
    private var pending: Int? = null
    private val tts: android.speech.tts.TextToSpeech = android.speech.tts.TextToSpeech(ctx, { status ->
        ready = status == android.speech.tts.TextToSpeech.SUCCESS
        pending?.let { pending = null; if (ready) play(it) }
    }, pkg)

    fun play(item: Int) {
        if (!ready) { pending = item; return }
        val all = runCatching { tts.voices }.getOrNull().orEmpty()
        val info = if (item == 0) EnglishProxy.pickOffline(voices, Locale.US) else voices.getOrNull(item - 1)
        val voice = all.firstOrNull { it.name == info?.name }
        if (voice != null) tts.voice = voice else tts.language = Locale.US
        tts.setSpeechRate(rate)
        val params = Bundle().apply { putFloat(android.speech.tts.TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceAtMost(1f)) }
        tts.speak(ctx.getString(R.string.en_voice_sample), android.speech.tts.TextToSpeech.QUEUE_FLUSH, params, "sample")
    }

    fun release() { runCatching { tts.stop(); tts.shutdown() } }
}
