package ru.kost.ruvoice

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.color.DynamicColors

/** «Настройки» и «Английский» ([EXTRA_ENGLISH]) из меню ⋮: RulesFragment отдельным окном, тумблеры сохраняются в его onPause. */
class RulesActivity : AppCompatActivity() {
    /** Профиль сменили плиткой в шторке — окно заново с тумблерами нового профиля (recreate вернул бы старые). */
    private val profileWatch = ProfileWatch(this) {
        finish(); startActivity(Intent(this, RulesActivity::class.java).putExtras(intent)); overridePendingTransition(0, 0)
    }
    override fun onResume() { super.onResume(); profileWatch.resume() }
    override fun onPause() { profileWatch.pause(); super.onPause() }

    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_rules)
        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }
        val english = intent.getBooleanExtra(EXTRA_ENGLISH, false)
        if (english) setTitle(R.string.english_title)
        findViewById<MaterialToolbar>(R.id.toolbar).apply { if (english) setTitle(R.string.english_title); setNavigationOnClickListener { finish() } }
        if (savedInstanceState == null) supportFragmentManager.beginTransaction()
            .add(R.id.rules, RulesFragment().apply { arguments = Bundle().apply { putBoolean(RulesFragment.ARG_ENGLISH, english) } }).commit()
    }

    override fun onKeyShortcut(keyCode: Int, event: KeyEvent): Boolean = ctrlF(keyCode, event) || super.onKeyShortcut(keyCode, event)

    companion object {
        const val EXTRA_ENGLISH = "english"
    }
}
