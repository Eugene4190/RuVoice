package ru.kost.ruvoice.text

/**
 * Переключатели правил обработки текста (вкладка «Правила»). Всё включено по умолчанию, кроме
 * DEFAULT_OFF; off — ключи, переключённые относительно умолчания (для DEFAULT_OFF — включённые);
 * maxLen — предел длины куска для синтеза (Splitter.sentences), у книг; srMaxLen — у экранного чтеца (screenReader()).
 * Ключи и их порядок в UI — KEYS; подписи к ним лежат в strings.xml как rule_<key> / rule_<key>_hint.
 */
class Rules(val off: Set<String> = emptySet(), val maxLen: Int = MAX_LEN_DEFAULT, val focus: Int = FOCUS_DEFAULT,
            val srMaxLen: Int = SR_MAX_LEN_DEFAULT) {
    fun on(key: String) = (key in off) == (key in DEFAULT_OFF)
    /** Сила логического ударения `*слово*` для focus_mask модели; 0 — правило выключено. */
    val focusLevel get() = if (on("focus")) focus.coerceIn(FOCUS_MIN, FOCUS_MAX) else 0

    /** Те же правила с [key] во включённом или выключенном состоянии. */
    fun with(key: String, on: Boolean): Rules =
        if (on(key) == on) this else Rules(if (key in off) off - key else off + key, maxLen, focus, srMaxLen)

    /** Правила для запроса экранного чтеца (TalkBack и др.) — секция «Чтение с экрана» поверх общих:
     * быстрый старт, служебные символы словами, без голоса прямой речи и без тишины перед фразой. Паузы между
     * предложениями (sr_pauses_off), выгрузку модели (sr_keep_loaded), темп и высоту чтеца решает сервис. */
    fun screenReader(): Rules {
        // быстрый старт чтеца — своим правилом, независимо от книжного fast_start
        var r = with("fast_start", on("sr_fast_start"))
        if (on("sr_symbols")) r = r.with("symbol_names", true)
        // ссылки у чтеца решает sr_link_word; книжный link_domain («только сайт») сюда не переходит
        r = r.with("link_domain", false)
        if (on("sr_link_word")) r = r.with(LINK_WORD, true)
        if (on("sr_quote_off")) r = r.with("speech", false)
        if (on("sr_lead_in_off")) r = r.with("lead_in", false)
        // эхо ввода и удаления (LetterEcho) — у чтеца всегда, у книг — по тумблеру letter_echo_all
        r = r.with(LETTER_ECHO, true).with(SCREEN_READER, true)
        // свой предел куска: хвост длинного сообщения считается кусками покороче, и фраза, которой чтец перебил
        // чтение, не ждёт досчёта длинного куска (forward не прерывается; 400 символов — ~4 с на A32)
        return Rules(r.off, srMaxLen, r.focus, srMaxLen)
    }

    companion object {
        /** Служебный ключ, не тумблер: запрос от экранного чтеца (screenReader()). Эхо ввода и удаления
         * работает при нём или при включённом letter_echo_all. */
        const val LETTER_ECHO = "letter_echo"
        /** Служебный ключ, не тумблер: запрос экранного чтеца — предел куска меряется текстом для модели (Pipeline.plan). */
        const val SCREEN_READER = "screen_reader"
        /** Служебный ключ, не тумблер: ссылка — словом «ссылка» (sr_link_word, только чтецу), важнее drop_links. */
        const val LINK_WORD = "link_word"
        const val MAX_LEN_DEFAULT = 400
        const val SR_MAX_LEN_DEFAULT = 200
        const val MAX_LEN_MIN = 100
        const val MAX_LEN_MAX = 900
        /** Длина первого куска запроса при fast_start, ~5 с звука. */
        const val FAST_START_LEN = 100
        // focus_embedding модели — 4 строки (0..3), как intensity в apply_tts
        const val FOCUS_DEFAULT = 3
        const val FOCUS_MIN = 1
        const val FOCUS_MAX = 3

        /** Правила, выключенные по умолчанию. */
        val DEFAULT_OFF = setOf("symbol_names", "fast_start", "drop_links", "drop_emails", "drop_images", "en_proxy_books", "en_proxy_sr", "letter_echo_all", LETTER_ECHO, "verbose_log", "sr_link_word", LINK_WORD, SCREEN_READER)

        /** Порядок списка = порядок на экране. Вверху «Чтение с экрана» (только запросы экранного чтеца),
         * за ней «Разное» — для настроек без своего раздела. */
        val KEYS = listOf(
            "sr_fast_start", "sr_symbols", "sr_link_word", "sr_quote_off", "sr_lead_in_off", "sr_pauses_off", "sr_keep_loaded", "sr_phrase_disk",
            "symbol_names", "emoji", "letter_name", "letter_echo_all", "lead_in", "fast_start", "prefetch", "drop_links", "link_domain", "drop_emails", "drop_images", "read_links",
            "phones", "codes", "numbers", "arith", "cases", "roman", "roman_name", "dates", "day_month", "years", "times", "units",
            "degrees", "currency", "fractions", "spoons", "gen_suffix", "sections", "thousands", "footnotes",
            "abbrev", "spell_cyr", "class_letter", "spell_lat", "letter_digit", "latin", "homoglyphs",
            "en_proxy_books", "en_proxy_sr",
            "dehyphen", "soft_break", "punct", "ssml",
            "gram", "first_pl", "homo", "accentor", "yo", "hard_e", "prefix_space", "end_dot", "end_oxy", "short_word", "intonation", "focus", "exclaim", "question",
            "pause_semicolon", "pause_parens", "pause_min", "fast_cores",
            "verbose_log",
        )
        /** Ключ, с которого начинается новая секция → её заголовок (rules_section_<имя> в strings.xml). */
        val SECTIONS = mapOf("sr_fast_start" to "talkback", "symbol_names" to "misc", "phones" to "numbers", "abbrev" to "abbrev", "en_proxy_books" to "english", "dehyphen" to "split",
            "gram" to "stress", "pause_semicolon" to "audio", "verbose_log" to "debug")

        /** Строки экрана правил на вкладке языка [layer]: ключ и раздел, если ключ в нём первый видимый (заголовок —
         * над ним), иначе null. Ключей [TextLayer.unsupported] нет; [english] — страница «Английский» из меню ⋮, только
         * её раздел (в «Настройках» его нет). */
        fun rows(layer: TextLayer, english: Boolean = false): List<Pair<String, String?>> {
            var section = ""
            var shown = ""
            return KEYS.mapNotNull { key ->
                section = SECTIONS[key] ?: section
                if ((section == "english") != english || key in layer.unsupported) null
                else key to section.takeIf { it != shown }?.also { shown = it }
            }
        }
    }
}
